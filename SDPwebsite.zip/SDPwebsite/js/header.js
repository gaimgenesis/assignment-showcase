﻿//open homepage
function bufferhome() {
	var random = Math.floor(Math.random() * 7) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomouthome, random);
}

function zoomouthome(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openhome, 300);
}

function openhome() {
   window.open("default.php","_self");

}

//open profile
function bufferprofile() {
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutprofile, random);
}

function zoomoutprofile(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openprofile, 300);
}

function openprofile() {
   window.open("profile.php","_self");

}


//open games
function games(){
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutgame, random);
}


function zoomoutgame(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(opengames, 300);
}
function opengames() {
	window.open("games.php","_self");
	
}


//open quiz
function quizs(){
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutquiz, random);
}


function zoomoutquiz(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openquiz, 300);
}
function openquiz() {
	window.open("quiz.php","_self");
	
}


//open changepassword
function bufferpassword() {
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutpassword, random);
}


function zoomoutpassword(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openpassword, 300);
}

function openpassword() {
   window.open("changepassword.php","_self");

}

//open login
function bufferlogin() {
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutlogin, random);
}


function zoomoutlogin(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openlogin, 300);
}

function openlogin() {
   window.open("login.php","_self");

}

//open register
function bufferregister() {
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutregister, random);
}


function zoomoutregister(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openregister, 300);
}

function openregister() {
   window.open("register.php","_self");

}


//open accountSetting
function bufferaccountSetting() {
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutaccountSetting, random);
}


function zoomoutaccountSetting(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openaccountSetting, 300);
}

function openaccountSetting() {
   window.open("accountSetting.php","_self");

}



//open changePassword
function bufferchangePassword() {
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutchangepassword, random);
}


function zoomoutchangepassword(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(openchangepassword, 300);
}

function openchangepassword() {
   window.open("changepassword.php","_self");

}
	
//open Notifications
function buffernotification() {
	var random = Math.floor(Math.random() * 10) * 100 + 600;
	document.getElementById('buffer').style.display = "block";
	setTimeout(zoomoutnotification, random);
}


function zoomoutnotification(){
	document.getElementById('bufferout').classList.add("zoomout");
	setTimeout(opennotification, 300);
}

function opennotification() {
   window.open("Notification.php","_self");

}