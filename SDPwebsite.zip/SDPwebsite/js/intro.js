﻿function introtoggle() {
	var intro = document.getElementById('intro');
	if (intro.style.width <= "80px") {
		document.getElementById('introbackid').style.display = "block";
		intro.classList.add('introopen');
		setTimeout(introcontent, 1600);
	} else {
	
	}
}

function introcontent() {
	document.getElementById('introcontentid').style.display = "block";
	document.getElementById('intro').style.cursor = "default";
}

window.onclick = function(event) {
	var introback = document.getElementById('introbackid');
	var intro = document.getElementById('intro');
    if (event.target == introback) {
        introback.style.display = "none";
		document.getElementById('introcontentid').style.display = "none";    
        intro.classList.add('introclose');
        intro.classList.remove('introopen');
        document.getElementById('intro').style.cursor = "pointer";
        setTimeout(removeclass, 1300);
    }
}
function removeclass() {
	var intro = document.getElementById('intro');
		document.getElementById('introcontentid').style.display = "none";    
        intro.classList.remove('introclose');
}


