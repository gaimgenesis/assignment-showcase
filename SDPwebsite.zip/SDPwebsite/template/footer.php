<div class="container" style="background: #011A47; width:100%; padding:40px 20px; color:white;">
  <div class="row">
  
    <div class="col-xs-3" style="text-align:justify;" >
      <section class="call-to-action">
      <!-- .rows and .columns -->
      <span style="font-size:40px" class="glyphicon glyphicon-thumbs-up glyphicon-large" aria-hidden="true"></span>
      <!-- /.rows and .columns -->
      </section>
      <h3 style="text-align:center"><b>Greeting!</b></h3> 
      <p>Our mission is to provide a free, world-class education to anyone, anywhere.</p>
    </div>
    
    <div class="col-xs-3"  style="text-align:center">
      <section class="call-to-action">
      <!-- .rows and .columns -->
      <span style="font-size:40px" class="glyphicon glyphicon-info-sign glyphicon-large" aria-hidden="true"></span>
      <!-- /.rows and .columns -->
      </section>
      <h3><b>More information</b></h3>  
      <p>About us</p>
      <p>FAQ</p>


    </div>
    <div class="col-xs-3"  style="text-align:center">
      <section class="call-to-action">
      <span style="font-size:40px" class="glyphicon glyphicon-globe glyphicon-large" aria-hidden="true"></span>
      </section>
      <h3><b>Social media</b></h3>
      <p>Facebook:</p>
      <p>Instagram:</p>
      <p>Twitter:</p>
    </div>
    <div class="col-xs-3"  style="text-align:center">
      <section class="call-to-action">
      <span style="font-size:50px" class="glyphicon glyphicon-phone-alt glyphicon-large" aria-hidden="true"></span>
      </section>
      <h3><b>Contact us</b></h3>
      <p>Email:</p>
      <p>Contact number:</p>
      <p>Address:</p>
    </div>
  </div>
</div>