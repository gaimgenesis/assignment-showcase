<div class="logo">
<img alt="brand logo" src="images/Logo.PNG" />
</div>

    <?php 
        session_start();
            echo'<nav class="navbar navbar-inverse" style="height: 53px">
                    <div class="container-fluid">
                      <ul class="nav navbar-nav"> 
                        <li><a href="#" onclick="quitquiz()">Quit</a></li>

                      </ul>

                          <ul class="nav navbar-nav navbar-right">
                            <li><a href="#"><span class="glyphicon glyphicon-user"></span> '.$_SESSION['uname'].'</a></li>
                            <li><button onclick="logout()"><span class="glyphicon glyphicon-log-in"></span> Logout</button></li>
                          </ul>;
                	</div>
                </nav>';
    ?>

        <div id="quiz" class="quitquiz" onclick="closequitquiz()"><div class="confirmquitquiz">
		<h1>Are you sure you want to Quit?</h1><br/>
          <button name="submit" class="logoutbtn" onclick="quizs()">Quit</button>

        </div></div>

        <script>
       	 function quitquiz() {
          document.getElementById('quiz').style.display = "block";
          }  
         function closequitquiz() {
          document.getElementById('quiz').style.display = "none";
         }      
        </script>
                <center>
                	<div id="buffer" class="buffback"><div class="lds-circle animate" id="bufferout"><div></div></div></div>
                </center>
        <div id="logout" class="logout" onclick="closelogout()"><div class="confirmlogout">
          <form action="backend/logout.inc.php" method="POST"><h1>Are you sure you want to Logout?</h1><br/>
          <button type="submit" name="submit" class="logoutbtn">LOGOUT</button>
          </form>
        </div></div>


        <script>
          function logout() {
          document.getElementById('logout').style.display = "block";
          }  
         function closelogout() {
          document.getElementById('logout').style.display = "none";
         }
  
        </script>

        		<!----snow----->
		
		<div class="snowflakes" style="aria-hidden: true;visibility: hidden;" id="snowtoggle">
		  <div class="snowflake">❅</div>
		  <div class="snowflake">❅</div>
		  <div class="snowflake">❆</div>
		  <div class="snowflake">❄</div>
		  <div class="snowflake">❅</div>
		  <div class="snowflake">❆</div>
		  <div class="snowflake">❄</div>
		  <div class="snowflake">❅</div>
		  <div class="snowflake">❆</div>
		  <div class="snowflake">❄</div>
		</div>  
		  <input type="button" class="snowbutton" id="snowonclick" onclick="snowtoggle()" value="❆"/>
		   
		<!-----snow---->