<!--------------------intro---------------------------->
		<div class="introback" id="introbackid"></div>
		
			<button class="introbutton" onclick="introtoggle()" id="intro"><i class="fa fa-info-circle">
				<div class="introcontent" id="introcontentid">
				<img src="images/Logo.PNG"/>
				<h2 class="welcometexth2">Welcome to Elevate Academy</h2>
				<br/>
				<p class="welcometextp">In here you could get to learn math quicker and efficient than ever!!</p>
				<img src="images/introImage.jpg" class="welcomeimage"/>
				</div>
			</i></button>
<!--------------------/intro---------------------------->

<!----------------------Logged In View--------------------------------->
<?php

include "backend/connect.php";
$id = $_SESSION['uid'];
$sql = "SELECT * from user where user_id=$id";
$result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)<=0)
    {
      echo 'No results found :(';
    }
    while($row = mysqli_fetch_array($result))
    {
    	$hpoints = $row['user_honour_points'];
    }

?>
<div class="Mainpage" id="profilebackground">
<center>
	<div class="profilephoto">
		<!-- Show profile picture -->
		<?php 
		include_once 'backend/connect.php';

					$sqlImg = "SELECT * FROM profileimg WHERE user_id_fk = '{$_SESSION['uid']}'";
					$resultImg = mysqli_query($conn,$sqlImg);
					$countImg = mysqli_num_rows($resultImg);
					if ($countImg > 0) {
						while ($rowImg = mysqli_fetch_assoc($resultImg)) {
							echo "<div>";
								if ($rowImg['status'] == 0) {
									$filename = "uploads/profile".$_SESSION['uid']."*";
									$fileinfo = glob($filename);
									$fileext = explode(".", $fileinfo[0]);
									$fileactualext = $fileext[1];

									echo "<img src='uploads/profile".$_SESSION['uid'].".".$fileactualext."?'".mt_rand()." class='img-circle profileicon' >";
								} else{
								// status is not 0, means user exists but does not have profile picture yet.
									echo "<img src='uploads/profiledefault.png' class='img-circle profileicon'>";
								}
							echo "</div>";
						}
					} else {
						echo "Error loading this user profile picture.";
					}
			 
		 ?>
		  <div class="overlay" onclick="bufferprofile()"><div class="viewprofiletext">View Profile</div></div>		
		
	</div>
			<h1 class="hpinfo">Your Current Honour Points: <span class="count"><?php echo $hpoints;?></span> </h1>
<script>
$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 3000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});
</script>
<div class="gamebutton">
		<div id="buffer" class="buffback"><div class="lds-circle animate" id="bufferout"><div></div></div></div>
	<button class="gamebtn" id="games" onclick="games()"><span>Games</span></button>
	<button class="quizbtn" id="quizs" onclick="quizs()"><span>Quiz</span></button>

</div>
</center>

</div>
<!----------------------/Logged In View--------------------------------->
