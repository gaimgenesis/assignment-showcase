<?php 
	session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
<style>
body {
margin: 0;
padding: 0;
background:  	#fffefe;
color: black;
font-family: "High Tower Text", sans-serif; 
overflow-x: hidden;
overflow-y: hidden;
animation: backgroundcolor 3s;
animation-fill-mode: both;
text-align: center;
}

@keyframes backgroundcolor{
	from {background-color: 	#fffefe}
	to {background-color: 	 	#cdf1f9}
}

.background{
	position:absolute;
	background-color: transparent;
	left: 10%;
	top: 10%;
	border-radius: 20px;
	width: 80%;
	height: 80%;
	text-align: center;
}

.managegame, .managequiz {
	position:absolute;
	width: 300px;
	height: 300px;
	border-radius: 200px;
	background-color:  	#059abd;
	text-align:center;
	top: 25%;
	font-size: 30px;
	color: white;
	border: medium white solid;
}

.managegame {
	left: 10%;
}
.managegame:active{
    border: medium red solid;
}

.managequiz {
	right: 10%;
}
.managequiz:active{
    border: medium red solid;
}
a {
	color: white;
}

.logout{
	position:absolute;
	bottom:50px;
	right: 50px;
	width: 100px;
	height: 60px;
	font-size: 15px;
	background-color: #3333CC;
	color: white;
	border-radius:5px;
}
</style>


<title>Admin Page</title>
</head>

<body>
<br/><br/>
<h1 style="font-size:50px;">Welcome back, <?php echo $_SESSION['aname']  ?>.</h1>
<div class="background">
<a href="managequiz.php"><button class="managequiz">Manage Quiz</button></a>
<a href="managegame.php"><button class="managegame">Manage Game</button></a>
</div>
<form action="backend/logout.inc.php" method="POST">
<button class="logout fa fa-sign-out" type="submit" name="submit">LOGOUT</button>
</form>
</body>

</html>
