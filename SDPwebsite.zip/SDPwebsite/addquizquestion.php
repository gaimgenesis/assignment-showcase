<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" type="text/css" href="css/login.css" />
<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/menu.css"/>
<link rel="stylesheet" type="text/css" href="css/quiz.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<title>Manage Quiz</title>

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}
.answersform {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}
.text, select{
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.ans, select{
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 40%;
  background-color: grey;
  border-color: black;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  font-size: 20px;
  font-weight: bolder;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: lime;
}
.back {
  width: 40%;
  background-color: orange;
  border-color: black;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  font-size: 20px;
  font-weight: bolder;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

.back:hover {
  background-color: red;
}
</style>
</head>

<body>

<!--- header ----->
<?php
  include "template/header.php";
?>
<!----/header ---->


<!--------------Login Form ----------------->
<div class="answersform">
<form action="backend/addquiz.inc.php" method="POST">
<h2>Add Questions</h2>
<br/>
<h3>Type in the question.</h3>
<input type="text" class="text" id="question" name="question" placeholder="Question Here...." required="required">
<h3>Type in the answers.</h3>
<input type="text" class="ans" id="ansname" name="answername1" placeholder="Answer 1 Here...." required="required">
<label class="correctans">
<input type="hidden" name="answers1" value="0" />
<input type="checkbox" value="1" name="answers1" />  Correct Answer<span class="checkmark"></span>
</label>
<input type="text" class="ans" id="ansname" name="answername2" placeholder="Answer 2 Here...." required="required">
<label class="correctans">
<input type="hidden" name="answers2" value="0" />
<input type="checkbox" value="1" name="answers2" />  Correct Answer<span class="checkmark"></span>
</label>
<input type="text" class="ans" id="ansname" name="answername3" placeholder="Answer 3 Here...." required="required">
<label class="correctans">
<input type="hidden" name="answers3" value="0" />
<input type="checkbox" value="1" name="answers3" />  Correct Answer<span class="checkmark"></span>
</label>
<input type="text" class="ans" id="ansname" name="answername4" placeholder="Answer 4 Here...." required="required">
<label class="correctans">
<input type="hidden" name="answers4" value="0" />
<input type="checkbox" value="1" name="answers4" />  Correct Answer<span class="checkmark"></span>
</label>
<br/>
<br/>
<input type="submit" value="Submit">
<input type="button" class="back" onclick="window.location.href='managequiz.php';" value="Finish Adding Questions?"/>
</form>
</div>
<script type="text/javascript">
        // the selector will match all input controls of type :checkbox
// and attach a click event handler 
$("input:checkbox").on('click', function() {
  // in the handler, 'this' refers to the box clicked on
  var $box = $(this);
  if ($box.is(":checked")) {
    // the name of the box is retrieved using the .attr() method
    // as it is assumed and expected to be immutable
    var group = "input:checkbox[name='" + $box.attr("name") + "']";
    // the checked state of the group/box on the other hand will change
    // and the current value is retrieved using .prop() method
    $(group).prop("checked", false);
    $box.prop("checked", true);
  } else {
    $box.prop("checked", false);
  }
});
    </script>

<!--------------Footer ----------------->
<?php  
include_once 'template/footer.php';
?>

<!--------------/footer------------------>


</body>

</html>
