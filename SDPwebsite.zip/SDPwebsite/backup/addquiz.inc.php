<?php
session_start();
$question = $_POST['question'];
$answers1 = $_POST['answers1'];
$answers2 = $_POST['answers2'];
$answers3 = $_POST['answers3'];
$answers4 = $_POST['answers4'];
$answer1 = $_POST['answername1'];
$answer2 = $_POST['answername2'];
$answer3 = $_POST['answername3'];
$answer4 = $_POST['answername4'];
$quizid = $_SESSION['quizid'];

include "backend/connect.php";

$sql0 = "Insert into quiz_question (quiz_question, quiz_id_fk) VALUES ('$question','$quizid');";
mysqli_query($conn, $sql0); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('Quiz has already been created!');</script>");
}
$sql = "Select * from quiz_question where quiz_question = '$question'";
$result = mysqli_query($conn, $sql); 
if(mysqli_num_rows($result)<=0) //no result
	{
		die("<script>alert('No data found in the DB!');</script>");
	}
	
	if($rows = mysqli_fetch_array($result)) //if got result
	{	
		$questionid = $rows['quiz_question_id'];
	}
$sql1 = "Insert into quiz_answer (quiz_answer, quiz_question_id_fk, correct_answer) VALUES ('$answer1','$questionid','$answers1');";
mysqli_query($conn, $sql1); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('Quiz has already been created!');</script>");
}
$sql2 = "Insert into quiz_answer (quiz_answer, quiz_question_id_fk, correct_answer) VALUES ('$answer2','$questionid','$answers2');";
mysqli_query($conn, $sql2); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('Quiz has already been created!');</script>");
}
$sql3 = "Insert into quiz_answer (quiz_answer, quiz_question_id_fk, correct_answer) VALUES ('$answer3','$questionid','$answers3');";
mysqli_query($conn, $sql3); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('Quiz has already been created!');</script>");
}
$sql4 = "Insert into quiz_answer (quiz_answer, quiz_question_id_fk, correct_answer) VALUES ('$answer4','$questionid','$answers4');";
mysqli_query($conn, $sql4); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('Quiz has already been created!');</script>");
}
echo "<script>alert('Quiz Question Inserted!')</script>";
echo "<script>window.location.href='addquizquestion.php';</script>";

?>