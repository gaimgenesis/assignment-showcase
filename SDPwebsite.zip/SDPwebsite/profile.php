﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,700"/>
<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/profile.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css" />
<script type="text/javascript" src="js/header.js"></script>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>


<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}

/*.navbar-inverse .navbar-nav .dropdown-menu li a:hover {
  background: #2C463C;
} */

</style>

<title>User Profile</title>
</head>

<body>
<!--- header ----->
<?php 
include_once 'template/header.php';
	if (!isset($_SESSION['uemail'])) {
		echo "<script>alert('Please login first.');</script>";
		die  ("<script>window.location.href='login.php'</script>");
	}
?>
<!----/header ---->



<div class="Mainpage" id="profilebackground">
<center>
	<div class="profilephoto">
		<label for="file-input">
			<!-- show proile img -->
			<?php 
			include_once 'backend/connect.php';

						$sqlImg = "SELECT * FROM profileimg WHERE user_id_fk = '{$_SESSION['uid']}'";
						$resultImg = mysqli_query($conn,$sqlImg);
						$countImg = mysqli_num_rows($resultImg);
						if ($countImg > 0) {
							while ($rowImg = mysqli_fetch_assoc($resultImg)) {
								echo "<div>";
									if ($rowImg['status'] == 0) {
										$filename = "uploads/profile".$_SESSION['uid']."*";
										$fileinfo = glob($filename);
										$fileext = explode(".", $fileinfo[0]);
										$fileactualext = $fileext[1];

										echo "<img src='uploads/profile".$_SESSION['uid'].".".$fileactualext."?'".mt_rand()." class='img-circle profileicon' >";
									} else{
									// status is not 0, means user exists but does not have profile picture yet.
										echo "<img src='uploads/profiledefault.png' class='img-circle profileicon'>";
									}
								echo "</div>";
							}
						} else {
							echo "Error loading this user profile picture.";
						}
					
				 
			 ?>
<!-- 		<img src="images/img_avatar.png" class="img-circle profileicon"/>  -->
		<div class="overlay" onclick="bufferaccountSetting()"><div class="viewprofiletext" onclick="bufferaccountSetting()">Account Settings</div></div>
		</label>
	</div>
			<?php
			include "backend/connect.php";
			$uid = $_SESSION['uid'];
			$sql = "SELECT * from user where user_id = $uid";
			$result = mysqli_query($conn,$sql);
			if(mysqli_num_rows($result)<=0)
			  {
			    echo "Cannot store results.";
			  }
			  while($row=mysqli_fetch_array($result))
			  {
			  	$userpoints = $row['user_honour_points'];
			  	$username = $row['user_name'];
			  	$useremail = $row['user_email'];
			  }
			?>
	<div class="profileinfo">
	<table>
	<tr>
		<td><p class="scoreboardtextrow profileinfocont1">PlayerName: <?php echo $username; ?></p></td>
		<td style="width: 300px;"></td>
		<td><p class="scoreboardtextrow profileinfocont2">PlayerEmail: <?php echo $useremail ; ?></p></td>
	</tr>
	<tr>

		<td><p class="scoreboardtextrow profileinfocont1">PlayerHonourPoints: <?php echo $userpoints; ?></p></td>
		<td style="width: 300px;"></td>
		<td><br/><br/><br/><button class="scoreboardtextrow profileinfocont2 mailbox" onclick="mailbox()"></button></td>
	</tr>
	</table>
	
	<script>
	function mailbox() {
		document.getElementById('mailbackground').style.display = 'block';
	}
	</script>
	<div class="Mailbackground" id="mailbackground">
		<div class="mailcontent">
			<span onclick="document.getElementById('mailbackground').style.display='none'" class="closebtn" title="Close Modal">&times;</span>
			<center><img src="images/Mailbox.png" class="imagebackground" /></center>
			<h2 class="mailheader">MAILBOX</h2>
				<div class="receivedmail">
<?php 
include "backend/connect.php";
$id = $_SESSION['uid'];
// $gameid = $_POST['gid'];
$sql = "SELECT * FROM user where user_id = $id";
$result = mysqli_query($conn, $sql);
      
      if(mysqli_num_rows($result)<=0)
      {
        die ("<script>alert('No data found in the DB!');</script>");
      }
      while($row = mysqli_fetch_array($result))
    {
      $score = (int)$row['user_honour_points'];
      // echo $score;
      // echo "<br/>";
    }
    $sql2 = "SELECT * FROM user INNER JOIN user_game ON user.user_id =user_game.user_id_fk   WHERE notification =1 AND opponent = $id  ";

  // echo $sql2;

  $result2 = mysqli_query($conn, $sql2);
  if(mysqli_num_rows($result)<=0)
      {
        echo "<h1>No users are near your honour points range at the moment. :( </h1>";
        echo "<button onclick='games.php' value='Back to Game Menu.'>Back to Game Menu.</button>";
      }
      while($row = mysqli_fetch_array($result2))
    {
      echo "<form action='backend/entergame.inc.php' method='POST'>";
      echo "<input type='hidden' name='userid' value='".$row['user_id']."'/>";
      echo "<input type='hidden' name='currentuser' value='$id'/>";
      echo "<input type='hidden' name='gameid' value='".$row['game_id_fk']."'/> ";
      echo "<button type='submit' class='hyperlink' value='Challenge!'>".$row['user_name']." is tried to Challange you!! Click here to check it out!</button>";

      echo "</form><br/>";
     // echo $row['Opponent'];
    }
?>
				</div>
			
		</div>
	</div>
	
	</div>
	<div class="scoreboard">
		<div class="board">
			<br/>
			<h2 class="scoreboardtext"><b>Scoreboard</b></h2>
			<br/>
			<table><tr><td>
			<div class="scoreboardtextrow scoreboardoverflow" style="margin-right:100px">
				<h3 class="scoreboardtext">Games</h3>
<?php 
include "backend/connect.php";
$id = $_SESSION['uid'];
// $gameid = $_POST['gid'];
$sql = "SELECT * FROM user where user_id = $id";
$result = mysqli_query($conn, $sql);
      
      if(mysqli_num_rows($result)<=0)
      {
        die ("<script>alert('No data found in the DB!');</script>");
      }
      while($row = mysqli_fetch_array($result))
    {
      $score = (int)$row['user_honour_points'];
      // echo $score;
      // echo "<br/>";
    }
    $sql2 = "SELECT * FROM user INNER JOIN user_game on user.user_id = user_game.user_id_fk INNER JOIN game_result ON user_game.user_game_id = game_result.user_game_id_fk Inner join game on game.game_id = user_game.game_id_fk where user.user_id =$id order by user_game.user_game_date DESC ";

  // echo $sql2;
  $result2 = mysqli_query($conn, $sql2);
  if(mysqli_num_rows($result)<=0)
      {
        echo "<h1>No users are near your honour points range at the moment. :( </h1>";
        echo "<button onclick='games.php' value='Back to Game Menu.'>Back to Game Menu.</button>";
      }
      while($row = mysqli_fetch_array($result2))
    {
      echo "<p class='scoreboardtextrow'>You have scored total points of ".$row['game_result_score']." on ".$row['user_game_date']." in ".$row['game_name']."</p>";
     // echo $row['Opponent'];
    }
?>  
</div>
</td><td>
<div class="scoreboardtextrow scoreboardoverflow">
<h3 class="scoreboardtext">Quizs</h3>
<?php 
include "backend/connect.php";
$id = $_SESSION['uid'];
// $gameid = $_POST['gid'];
$sql = "SELECT * FROM user where user_id = $id";
$result = mysqli_query($conn, $sql);
      
      if(mysqli_num_rows($result)<=0)
      {
        die ("<script>alert('No data found in the DB!');</script>");
      }
      while($row = mysqli_fetch_array($result))
    {
      $score = (int)$row['user_honour_points'];
      // echo $score;
      // echo "<br/>";
    }
    $sql3 = "SELECT * FROM user INNER JOIN user_quiz on user.user_id = user_quiz.user_id_fk INNER JOIN quiz_result ON user_quiz.user_quiz_id = quiz_result.user_quiz_id_fk inner join quiz on quiz.quiz_id = user_quiz.quiz_id_fk 

where user.user_id = $id order by user_quiz.user_quiz_date DESC ";

  // echo $sql2;
  $result3 = mysqli_query($conn, $sql3);
  if(mysqli_num_rows($result)<=0)
      {
        echo "<h1>No users are near your honour points range at the moment. :( </h1>";
        echo "<button onclick='games.php' value='Back to Game Menu.'>Back to Game Menu.</button>";
      }
      while($row = mysqli_fetch_array($result3))
    {
      echo "<p class='scoreboardtextrow'>You have scored total points of ".$row['quiz_result_score']." on ".$row['user_quiz_date']." in ".$row['quiz_name']."</p>";
     // echo $row['Opponent'];
    }
?>  			
			</div>
			</td></tr></table>
			<br/>
			
		</div>	
	</div>
</center>
</div>
<!----footer---->

<?php  
include_once 'template/footer.php';
?>

<!----/footer---->

</body>

</html>
