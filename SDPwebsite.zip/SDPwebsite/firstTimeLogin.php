<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />

<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>
<link rel="stylesheet" type="text/css" href="css/intro.css" />
<link rel="stylesheet" type="text/css" href="css/firstTimeLogin.css"/>


<meta name="viewport" content="width=device-width, initial-scale=1"/>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
padding:0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: hidden;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}

/*.navbar-inverse .navbar-nav .dropdown-menu li a:hover {
  background: #2C463C;
} */


</style>

<script>
function FTLbackground() {
	document.getElementById('FTLbackground').style.display ="block";
}
</script>

<title>Main Page</title>
</head>
<body onload="FTLbackground()">

<!---------------First Time Login------------------->
<script>
function FTL() {
	document.getElementById('FTLintro').classList.add('fadeout');
	setTimeout(document.getElementById('but').style.cursor='default',1000);
}
</script>
<div class="background" id="FTLbackground">
	<div class="FTLintro" id="FTLintro">
		<p class="FTLheading animation">WELCOME TO ELEVATE ACADEMY</p><br/><br/>
		<button class="GetStarted" id="but" onclick="FTL()">Get Started</button>
	</div>
</div>

<!---------------/First Time Login------------------->

		<!-----intro--->
		<div class="introback" id="introbackid"></div>
		
			<button class="introbutton" onclick="" id="intro"><i class="fa fa-info-circle">
				<div class="introcontent" id="introcontentid">
				<img src="images/Logo.PNG"/>
				<h2 class="welcometexth2">Welcome to Elevate Academy</h2>
				<br/>
				<p class="welcometextp">In here you could get to learn math quicker and efficient than ever!!</p>
				<img src="images/introImage.jpg" class="welcomeimage"/>
				</div>
			</i></button>
		
		<!-----intro--->


<!--- header ----->
<?php 

include_once 'template/header.php';

?>

<!----/header ---->
<div class="Mainpage" id="profilebackground">
<center>
	<div class="profilephoto">
		<img src="images/img_avatar.png" class="img-circle profileicon" alt="Avatar" />
		  <div class="overlay" onclick=""><div class="viewprofiletext">View Profile</div></div>		
		
	</div>
			<h1 class="hpinfo">Your Current Honour Points: </h1>

<div class="gamebutton">
		<div id="buffer" class="buffback"><div class="lds-circle animate" id="bufferout"><div></div></div></div>
	<button class="gamebtn" id="games" onclick=""><span>Games</span></button>
	<button class="quizbtn" id="quizs" onclick=""><span>Quiz</span></button>

</div>
</center>

</div>
<!----footer---->

<?php  
include_once 'template/footer.php';
?>

<!----/footer---->

</body>

</html>
