<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/search.css"/>
<link rel="stylesheet" type="text/css" href="css/opponent.css"/>
<script type="text/javascript" src="js/header.js"></script>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>


<meta name="viewport" content="width=device-width, initial-scale=1"/>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<title>Game</title>

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}

</style>
</head>

<body>

<!--- header ----->
<?php 

include_once 'template/header.php';

?>
<!----/header ---->
<div class="answersform">
<?php 
include "backend/connect.php";
$id = $_SESSION['uid'];
$gameid = $_POST['gid'];
$sql = "SELECT * FROM user where user_id = $id";
$result = mysqli_query($conn, $sql);
      
      if(mysqli_num_rows($result)<=0)
      {
        die ("<script>alert('No data found in the DB!');</script>");
      }
      while($row = mysqli_fetch_array($result))
    {
      $score = (int)$row['user_honour_points'];
      // echo $score;
      // echo "<br/>";
    }
    $up = $score - 100;
    $down = $score + 100;
    $sql2 = "SELECT * FROM user WHERE user_honour_points BETWEEN $up AND $down LIMIT 5";
  // echo $sql2;
  $result2 = mysqli_query($conn,$sql2);
  if(mysqli_num_rows($result)<=0)
      {
        echo "<h1>No users are near your honour points range at the moment. :( </h1>";
        echo "<button onclick='games.php' value='Back to Game Menu.'>Back to Game Menu.</button>";
      }
       echo "<table id='gametopic'>";
      echo "<tr>";
      echo "<th>User ID</th>";
      echo "<th>Username</th>";
      echo "<th>Honour Points</th>";
      echo "<th>Challenge Them!</th>";
      echo "</tr>";
      while($row = mysqli_fetch_array($result2))
    {
      echo "<form action='backend/enterchallenge.inc.php' method='POST'>";
      echo "<tr>";
      echo "<td>".$row['user_id']."</td>";
      echo "<input type='hidden' name='opid' value='".$row['user_id']."'/>";
      echo "<input type='hidden' name='currentuser' value='$id'/>";
      echo "<input type='hidden' name='gameid' value='$gameid'/> ";
      echo "<td>".$row['user_name']."</td>";
      echo "<td>".$row['user_honour_points']."</td>";
      echo "<td><button type='submit' class='play play1' value='Challenge!'/>Challenge!</td>";
      echo "</tr>";
      echo "</form>";
    }
    echo"</table>";
?>
</div>
<!--------------Footer ----------------->
<?php  
include_once 'template/footer.php';
?>

<!--------------/footer------------------>


</body>

</html>