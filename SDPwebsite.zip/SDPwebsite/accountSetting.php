

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />

<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<script type="text/javascript" src="js/header.js"></script>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>
<link rel="stylesheet" type="text/css" href="css/accountSetting.css" />
<link rel="stylesheet" type="text/css" href="css/login.css" />
<script type="text/javascript" src="js/passwordvalidation.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1"/>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}

/*.navbar-inverse .navbar-nav .dropdown-menu li a:hover {
  background: #2C463C;
} */


</style>
<script type="text/javascript">
	function changepassword() {
		document.getElementById('background2').style.display = 'block';
	}

	function changeusername() {
		document.getElementById('background1').style.display = 'block';
	}

	function changeprofilepicture() {
		document.getElementById('background3').style.display = 'block';
	}	
</script>


<title>Account Setting</title>
</head>

<body>
<!--- header ----->
<?php 

//Redirect user to login page if they havent done so.
include_once 'template/header.php';
	if (!isset($_SESSION['uemail'])) {
		echo "<script>alert('Please login first.');</script>";
		die  ("<script>window.location.href='login.php'</script>");
	}

?>
		<div id="buffer" class="buffback"><div class="lds-circle animate" id="bufferout"><div></div></div></div>

<!----/header ---->
<!---Content------>
<div class="accountContainer">
<center>
	<div class="profilephoto" onclick="changeprofilepicture()">
		<label for="file-input">
		<!-- Show profile picture -->
		<?php 
		include_once 'backend/connect.php';
					$sqlImg = "SELECT * FROM profileimg WHERE user_id_fk = '{$_SESSION['uid']}'";
					$resultImg = mysqli_query($conn,$sqlImg);
					$countImg = mysqli_num_rows($resultImg);
					if ($countImg > 0) {
						while ($rowImg = mysqli_fetch_assoc($resultImg)) {
							echo "<div>";
								if ($rowImg['status'] == 0) {
									$filename = "uploads/profile".$_SESSION['uid']."*";
									$fileinfo = glob($filename);
									$fileext = explode(".", $fileinfo[0]);
									$fileactualext = $fileext[1];

									echo "<img src='uploads/profile".$_SESSION['uid'].".".$fileactualext."?'".mt_rand()." class='img-circle profileicon' >";
								} else{
								// status is not 0, means user exists but does not have profile picture yet.
									echo "<img src='uploads/profiledefault.png' class='img-circle profileicon'>";
								}
							echo "</div>";
						}
					} else {
						echo "Error loading this user profile picture.";
					}
			 
		 ?>
		<!-- <img src="images/img_avatar.png" class="img-circle profileicon" onclick="changepassword()"/> -->
		<div class="overlay"><div class="viewprofiletext">Change Profile Picture</div></div>
		</label>
	</div>
	<div class="changedetails">
		<h2 class="blink">Account Setting</h2>
			<table class="blink">
				<tr> 
					<td>Username : </td>
					<td><input type="button" value="Change" class="ChangeBtn" onclick="changeusername()"/></td>
				</tr>
				<tr>
					<td>Password : </td>
					<td><input type="button" value="Change" class="ChangeBtn" onclick="changepassword()"/></td>
				</tr>
<!-- 				<tr>
					<td>Profile Picture : </td>
					<td><input type="button" value="Change" class="ChangeBtn" onclick="changeprofilepicture()"/></td>
				</tr>	 -->			
			</table>
	</div>
</center>
</div>
<!----/content--->

<!-------------Change Password Form------------------------>
	<div id="background2" class="background animate">
		<div class="passwordcontent">
		      <span onclick="document.getElementById('background2').style.display='none'" class="closebtn" title="Close Modal">&times;</span>
			<form method="POST" action="backend/changepassword.inc.php" style="max-width:500px;margin:auto">
			  <h2 style="font-size:40px">Change Password</h2>
			  <br/><br/>
			
			  <div class="input-container">
			    <i class="fa fa-key icon"></i>
			    <input class="input-field" type="password" placeholder="Old Password" name="oldpsw" />
			  </div>
			  
			  <div class="input-container">
			    <i class="fa fa-key icon"></i>
			    <input class="input-field" type="password" placeholder="New Password*" id="pass" name="newpsw" 
			    oninput="password_validate(this);"
			    />
			  </div>
			
			
			  <div class="input-container">
			    <i class="fa fa-key icon"></i>
			    <input class="input-field" type="password" placeholder="Confirm New Password*" id="confirmedPassword" name="confnewpsw" />
			  </div>
			  
<!---------------Password Strength--------------------------->
				<label id="pass-hint">
				Password Strength: <span id="result"></span>
				<br/>
				<div class="progress" id="progres">
				<div class="progress-bar progress-bar-danger" role="progressbar" id="prog"></div>
				</div>
				</label>
				<span id="passerror"></span>
<!---------------/Password Strength--------------------------->

			  <div id="checkpasswordtext"></div>  
			  <br/><br/>
			  <div style="text-align:center">
			  <button type="submit" class="btnlogin" name="submit">Change Password</button>
			  </div>
			  
			  <br/><br/>  
			</form>
	
		</div>
	</div>
<!-------------/Change Password Form------------------------>
<script>
$(document).ready(function () {
   $("#confirmedPassword").keyup(checkPasswordMatch);
   $("#pass").keyup(checkPasswordMatch);
});

function checkPasswordMatch() {
    var password = $("#pass").val();
    var confirmPassword = $("#confirmedPassword").val();

    if (password != confirmPassword)
        $("#checkpasswordtext").html("Passwords do not match!");
    else
        $("#checkpasswordtext").html("Passwords match.");
}

</script>

<!--------------Change Username Form------------------------>
	<div id="background1" class="background animate">
		<div class="passwordcontent">
		      <span onclick="document.getElementById('background1').style.display='none'" class="closebtn" title="Close Modal">&times;</span>
			<form method="POST" action="backend/changeusername.inc.php" style="max-width:500px;margin:auto">
			  <h2 style="font-size:40px">Change Username</h2>
			  <br/><br/>
			
			  <div class="input-container">
			    <i class="fa fa-vcard-o icon"></i>
			    <input class="input-field" type="text" value="<?php  echo $_SESSION['uname'];  ?>" name="oldusn" readonly="readonly" />
			  </div>
			  <br/><br/>
			  <div class="input-container">
			    <i class="fa fa-vcard-o icon"></i>
			    <input class="input-field" type="text" placeholder="New Username*" name="newusn" />
			  </div>
			
						    
			  <br/><br/>
			  <div style="text-align:center">
			  <button type="submit" class="btnlogin" name="submit">Change Username</button>
			  </div>
			  
			  <br/><br/>  
			</form>
	
		</div>
	</div>


<!-------------/Change Username Form------------------------>
<!--------------Change Profile Picture Form----------------->
	<div id="background3" class="background2 animate">
		<div class="passwordcontent">
		      <span onclick="document.getElementById('background3').style.display='none'" class="closebtn" title="Close Modal">&times;</span>
		<form action="changeprofile.php" method="POST" enctype="multipart/form-data" style="max-width:500px;margin:auto">
				  <h2 style="font-size:40px">Change Profile Picture</h2>
				  <p style="font-size:20px">Click 'choose file' button to select a new image</p>
			<br/>
			<div class="container">
				<div class="row">
					<div class="profilephoto col-lg-3">
							<!-- show proile img -->
							<?php 
							include_once 'backend/connect.php';

										$sqlImg = "SELECT * FROM profileimg WHERE user_id_fk = '{$_SESSION['uid']}'";
										$resultImg = mysqli_query($conn,$sqlImg);
										$countImg = mysqli_num_rows($resultImg);
										if ($countImg > 0) {
											while ($rowImg = mysqli_fetch_assoc($resultImg)) {
												echo "<div>";
													if ($rowImg['status'] == 0) {
														echo "<img src='uploads/profile".$_SESSION['uid'].".".$fileactualext."?'".mt_rand()."'' class='img-circle profileicon2' >";
													} else{
													// status is not 0, means user exists but does not have profile picture yet.
														echo "<img src='uploads/profiledefault.png' class='img-circle profileicon2'>";
													}
												echo "</div>";
											}
										} else {
											echo "Error loading this user profile picture.";
										}
								 
							 ?>	

						<!-- <img src="images/img_avatar.png" class="img-circle profileicon2"/> -->
					</div>

					<div class="col-lg-5" style="top:140px">
						<input type="file" name="profileImage">
						<br/>
						<button type="submit" name="submit" class="btnlogin" >Upload Image</button>
					</div>
			
				</div>
			</div>					
							    
			<br/><br/><br/><br/><br/>
		</form>
	
		</div>
	</div>


<!-------------/Change Profile Picture Form------------------------>
<!----footer---->

<?php  
include_once 'template/footer.php';
?>

<!----/footer---->


</body>

</html>
