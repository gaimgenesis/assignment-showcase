<?php
  $id = $_GET['id'];
  include "backend/connect.php";
  if (isset($_GET['question_no']) && $_GET['question_no']!="") {
    $question_no = $_GET['question_no'];
    } else {
        $question_no = 1;
        }
        $total_records_per_page = 1;
$offset = ($question_no-1) * $total_records_per_page;
$next_page = $question_no + 1;
$adjacents = "2";
$result_count = mysqli_query(
$conn,
"SELECT COUNT(*) As total_records FROM quiz_question where quiz_id_fk = $id"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />

<link rel="stylesheet" type="text/css" href="css/login.css" />
<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/question.css"/>
<link rel="stylesheet" type="text/css" href="css/comments.css"/>
<script type="text/javascript" src="js/header.js"></script>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>
<script type="text/javascript" src="js/question.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1"/>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<style>


/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}
h3 {
  padding-left: 20px;
}
p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}
.username{
  font-size: 20px;
  color: black;
}

/*.navbar-inverse .navbar-nav .dropdown-menu li a:hover {
  background: #2C463C;
} */


</style>

<title>Quiz</title>
</head>


<body>
<!--- header ----->
<?php 

include_once 'template/quizheader.php';

?>
<!----/header ---->

<div class="scp-quizzes-main">
<div class="scp-quizzes-data">
  <?php 
  $result = mysqli_query(
    $conn, 
    "SELECT * FROM quiz_question where quiz_id_fk = $id LIMIT $offset, $total_records_per_page"
  );
  while($row = mysqli_fetch_array($result)){
    echo "<h3>".$row['quiz_question']."</h3>";
    $question = $row['quiz_question_id'];
  }
  
  ?>
<br/>
<div>

<?php 
$sql3 = "Select * from quiz_answer where quiz_question_id_fk = $question AND correct_answer = 1";
    $result = mysqli_query($conn, $sql3);
    if(mysqli_num_rows($result)<=0) //no result
  {
    echo "<script>alert('No answers found!');</script>";
  }
  while($row = mysqli_fetch_array($result))//if there are results
  {
    $answer = $row['quiz_answer'];
  }
  ?>
  <?php
    $sql2 = "Select * from quiz_answer where quiz_question_id_fk = $question";
    $result = mysqli_query($conn, $sql2);
    if(mysqli_num_rows($result)<=0) //no result
  {
    echo "<script>alert('No answers found!');</script>";
  }
  
  $quizansid = array(); 
  $quizans = array();
  $i = 0;
  while($row = mysqli_fetch_assoc($result)) //if got result
  {
     //echo $i;
     array_push($quizansid, $row['quiz_answer_id']); //assign all id into an array
     array_push($quizans, $row['quiz_answer']); //assign all answer into an array
     echo '<input type="radio" id="'.$row['quiz_answer_id'].'" name="q1" class="radiobtn" value="'.$row['quiz_answer'].'" onclick="check()"/><label for="'.$row['quiz_answer_id'].'" class="radiostyle" id="'.$i.'">"'.$row['quiz_answer'].'"</label>';  //loop out all question answer
    echo "<br/>";
    $i++;
  }
  // echo sizeof($quizansid);
  $answerindex = array_search($answer, $quizans); //find answerindex
  //echo $answerindex;
 ?>
<form method="POST" action="backend/checkquiz.inc.php">
  <input type="hidden" name="question" value="<?php echo $question_no;?>">
  <input type="hidden" name="total" value="<?php echo $total_records;?>">
  <input type="hidden" name="id" <?php echo "value=$id";?>>
  <input type="hidden" name="scores" id="scores" readonly="true"/>
  <input type="hidden" name="x" id="x" readonly="true"/>
  
  <br/><br/>
   <div id='checkans'>Select An Answer</div>
<button type="submit" class="nextbtn" id="next"><i class="fa fa-angle-right"></i></button>
</form>
<button class="comm" id="comments" onclick="comments()">View Comments</button><br/><br/>
</div>
<br/><br/>
</div>
<script>
  function comments()
  {
    document.getElementById('viewcomment').style.display = "block";
  }

</script>
<div class="viewcomments" id="viewcomment"><span class="closecomments" onclick="document.getElementById('viewcomment').style.display = 'none'">&times;</span>
<div class="commcontent">

    <?php
    $sql = "Select * from quiz_comments LEFT JOIN quiz_question ON quiz_question_id = quiz_question_id_fk LEFT JOIN user ON user_id_fk = user_id where quiz_question_id = $question";
  $result = mysqli_query($conn,$sql);
  if(mysqli_num_rows($result)<=0)
  {
    echo "No comments yet. Be the first comment!";
  }
  while($rows=mysqli_fetch_array($result))
  {
    echo "<table class='UCblock'>";
    echo  "<tr>";
    echo "<th style='width:10vw;''><div class='UCprofile'><img src='images/img_avatar.png' style='width:80px; height:80px;'/>";
    echo "</div>";
    echo "</th>";
    echo "<th>";
    echo "<div class='UCcommnet'>";
    echo "<p class='username'>".$rows['user_name']."   commented on   ".$rows['quiz_comment_date']."</p>";
    // echo "<p>".$rows['quiz_comment_date']."</P>";
    echo "<h4 style='font-size:1.5em'>".$rows['quiz_comment']."</h4>";
    echo "</div>";
    echo "</th>";
    
    echo "<th style='width:5vw;'><label class='UCupvote'>";
    echo "<input type='radio' value='upvote' name='vote0'/>";
    echo "<span class='checkmarkup'></span>";
    echo "</label>";
    echo "</th>";
    echo "<th>";
    echo "<input type='hidden' name='commentid' value='".$row['quiz_comment_id']."'/>";
    echo "<label>".$rows['quiz_comment_vote']."</label>";
    echo "</th>";
    echo "<th style='width:5vw;'><label class='UCdownvote'>";
    echo "<input type='radio' value='downvote' name='vote0'/>";
    echo "<span class='checkmarkdown'></span>";
    echo "</label>";
    echo "</th>";
    echo  "</tr>";
    echo "</table>"; 
  }

    ?>

    <br/><br/>
    <div class="commentform">
            <h5 class="card-header">Leave a Comment:</h5>
            <div class="card-body">
            <form method="POST" action="backend/addcomments.php">
              <input type="hidden" name="userid" 
              <?php
              echo "value='".$_SESSION['uid']."'"; ?>>
              <input type="hidden" name="directpage" value="<?php echo $_SERVER['PHP_SELF'] ?>">
              <input type="hidden" name="quizquestionid" 
              <?php echo "value=$id"; ?>>
              <input type="hidden" name="qid" value="<?php echo $question;?>">
              <input type="hidden" name="pageid" value="1">
              <div class="form-group">
                <textarea name="commenttext" required='required' class="form-control" rows="3"></textarea>
              </div>
              <?php
              echo "<button  type='submit' name='submitcomment' class='btn btn-primary'>Submit</button>";
                 ?>
                
               </form>
                </div>
          </div>
</div>

</div>

<br/><br/>
<br/>

</div>
<script>
  var ans = "<?php echo $answer;  ?>"; //assign php answer variable into javascript variable
  var questionsarr = [<?php echo '"'.implode('","', $quizans).'"' ?>]; //assign all php answer array into javascript array
  var questionsidarr = [<?php echo '"'.implode('","', $quizansid).'"' ?>]; //assign all php id array into javascript array
  var score = 0;
  function check() { 

    var radiobtn = $('input[name=q1]:checked').index() ; //user selected answer
    
    var userans = 0; 
    if (radiobtn == 3)
    {
      userans = 1;
    } else if (radiobtn == 6)
    {
      userans = 2;
    } else if (radiobtn == 9)
    {
      userans = 3;
    }
    if (($('input[name=q1]:checked').length > 0)) //if user selected an answer
    {

      if (userans == <?php echo $answerindex ?>) //if user selected answer is correct
      {
        document.getElementById('checkans').innerHTML = "CORRECT YOOO!!";
        document.getElementById('comments').style.display = "block";   //display comments button
        document.getElementById('next').style.display = "block";  //display next button
        document.getElementById('<?php echo $quizansid[0] ?>').disabled = true; //block user from reselect the answer
        document.getElementById('<?php echo $quizansid[1] ?>').disabled = true;
        document.getElementById('<?php echo $quizansid[2] ?>').disabled = true;
        document.getElementById('<?php echo $quizansid[3] ?>').disabled = true;
        document.getElementById('<?php echo $answerindex ?>').style.backgroundColor = "green"; //change corrent answer backgroundcolor
        document.getElementById('<?php echo $answerindex ?>').style.color = "white"; //change correct answer font color
        score+=10;
        document.getElementById('scores').value = score;

      }
      else //if user selected answer is wrong
      {
        document.getElementById('checkans').innerHTML = "SALAH!!";
        document.getElementById('comments').style.display = "block";  //display comments button
        document.getElementById('next').style.display = "block";  //display next button
        document.getElementById('<?php echo $quizansid[0] ?>').disabled = true; //block user from reselect the answer
        document.getElementById('<?php echo $quizansid[1] ?>').disabled = true;
        document.getElementById('<?php echo $quizansid[2] ?>').disabled = true;
        document.getElementById('<?php echo $quizansid[3] ?>').disabled = true;
        document.getElementById('<?php echo $answerindex ?>').style.backgroundColor = "green"; //change corrent answer backgroundcolor
        document.getElementById(userans).style.color = "white";  //change correct answer font color
        document.getElementById(userans).style.backgroundColor = "red";  //change user selected answer backgroundcolor
        document.getElementById('<?php echo $answerindex ?>').style.color = "white"; //change user selected answer font color
        document.getElementById('scores').value = score;

      }
    }
    else
    {
      document.getElementById('checkans').innerHTML = "Please Select an Answer";
    }
  }
</script>

<?php 
/*
   if (isset($_POST["q1"]))
   {
    if ($answer == $_POST["q1"])
    {
       echo "correct!";
      $class = 'correct';
    }
    else{
      echo "Wrong!";
      $class = 'wrong';
   }
 }

   echo "border-color:green ";

   */
?>

<!----footer---->

<?php  
include_once 'template/footer.php';
?>

<!----/footer---->

</body>

</html>