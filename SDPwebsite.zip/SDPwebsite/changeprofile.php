<?php 
session_start();

//Check if the picture is legit.
if (isset($_POST['submit'])) {
	$file = $_FILES['profileImage'];
	//print_r($file);

	$fileName = $_FILES['profileImage']['name'];
	$fileTmpName = $_FILES['profileImage']['tmp_name'];
	$fileType = $_FILES['profileImage']['type'];
	$fileSize = $_FILES['profileImage']['size'];
	$fileError = $_FILES['profileImage']['error'];

	$fileExt = explode('.',$fileName);
	$fileActualExt = strtolower(end($fileExt));

	$allowed = array('jpg','jpeg','png');

	if (in_array($fileActualExt, $allowed)) {
		if ($fileError === 0) {
			if ($fileSize < 5000000) {	
				//Remove the old picture
				$oldfilename = "uploads/profile".$_SESSION['uid']."*";
				$oldfileinfo = glob($oldfilename);
				$oldfileext = explode(".", $oldfileinfo[0]);
				$oldfileactualext = $oldfileext[1];
				$oldfileactualname = "uploads/profile".$_SESSION['uid'].".".$oldfileactualext;

					//Remove old picture
					if (!unlink($oldfileactualname)) {
						echo "<script>alert('There's a problem removing old picture.');</script>";
					} else {
						echo "<script>alert('Profile picture updated !');</script>";
					}


				//Upload the new picture
				$fileNameNew = "profile".$_SESSION['uid'].".".$fileActualExt;
				$fileDestination = 'uploads/'.$fileNameNew;
				move_uploaded_file($fileTmpName, $fileDestination);

				//Update the status of profile picture in database
				include_once 'backend/connect.php';

				$thisUid = mysqli_real_escape_string($conn,$_SESSION['uid']);
				$sql = "SELECT * FROM profileimg WHERE user_id_fk='$thisUid'";
				$result = mysqli_query($conn,$sql);

					if (mysqli_num_rows($result) > 0) {
						$sql2 = "UPDATE profileimg SET status = '0' WHERE user_id_fk='{$_SESSION['uid']}'"; 
						mysqli_query($conn,$sql2);

					} else {
						echo"There is a problem updating your profile picture due to technical difficulties. Please try again later!";
					}

				die("<script>window.location.href='accountSetting.php?uploadsuccess'</script>");

			} else {
				echo"<script>alert('Sorry, Your file is too big. Please choose another picture.');</script>";
				die  ("<script>window.location.href='accountSetting.php'</script>");
			}
			
		} else {
			echo"<script>alert('Sorry, there was an error uploading your file. Please try again later.');</script>";
			die  ("<script>window.location.href='accountSetting.php'</script>");
		}
		
	} else{
		echo"<script>alert('You cannot upload file of this type. Please choose another picture.');</script>";
		die  ("<script>window.location.href='accountSetting.php'</script>");
	}
}

 ?>