<?php
	//new page named delete.php
	//connection
	include_once "connect.php";
	$id = $_GET['id'];

	$sql="Delete from game_question_answer where game_id_fk= $id";
	$sql2="Delete from game_question where game_id_fk= $id";
	$sql3="Delete from game where game_id= $id";
	mysqli_query($conn, $sql);
	
	// check the affected row number
	if(mysqli_affected_rows($conn) <=0)
	{
		echo "<script>alert('Unable to delete the data!');</script>";
		die("<script>window.location.href='../managegame.php';</script>");
	}
	mysqli_query($conn, $sql2);
	
	// check the affected row number
	if(mysqli_affected_rows($conn) <=0)
	{
		echo "<script>alert('Unable to delete the data!');</script>";
		die("<script>window.location.href='../managegame.php';</script>");
	}
	mysqli_query($conn, $sql3);
	
	// check the affected row number
	if(mysqli_affected_rows($conn) <=0)
	{
		echo "<script>alert('Unable to delete the data!');</script>";
		die("<script>window.location.href='../managegame.php';</script>");
	}

	echo "<script>alert('Game deleted');</script>";
	die("<script>window.location.href='../managegame.php';</script>");
?>