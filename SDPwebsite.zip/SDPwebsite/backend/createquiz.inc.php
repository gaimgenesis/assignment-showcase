<?php 
session_start();
$topic = $_POST['topic'];
$aid = $_SESSION['aid'];

include_once "connect.php";

$sql = "Insert into quiz (quiz_name, admin_id_fk) VALUES('$topic','$aid');";
echo $sql;
mysqli_query($conn, $sql); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('Quiz has already been created!');</script>");
}
$sql2 = "Select * from quiz where quiz_name = '$topic'";
$result = mysqli_query($conn, $sql2); 
if(mysqli_num_rows($result)<=0) //no result
	{
		die("<script>alert('No data found in the DB!');</script>");
	}
	
	if($rows = mysqli_fetch_array($result)) //if got result
	{	
		$_SESSION['quizid'] = $rows['quiz_id'];
		$quizname = $rows['quiz_name'];
		$quizadmin = $rows['admin_id_fk'];
	}
echo "<script>alert('Quiz Topic Inserted!')</script>";
echo "<script>window.location.href='../addquizquestion.php';</script>";
?>