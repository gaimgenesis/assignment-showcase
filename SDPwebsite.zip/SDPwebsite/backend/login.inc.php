<?php 

session_start();
	
if(isset($_POST['submit'])){
		
		include_once 'connect.php';

		$uemail = mysqli_real_escape_string($conn, $_POST['email']);
		$upsw = mysqli_real_escape_string($conn, $_POST['psw']);

		//Error handlers
		//Check if inputs are empty
		if(empty($uemail) || empty($upsw)){

			echo "<script>alert('Please fill up all the fields.');</script>";
			die  ("<script>window.location.href='../login.php'</script>");

		} else{
			$sqladmin = "SELECT * FROM admin WHERE admin_email='$uemail'";
			$resultadmin = mysqli_query($conn,$sqladmin);
			$resultcheckadmin = mysqli_num_rows($resultadmin);

		
			$sql = "SELECT * FROM user WHERE user_email='$uemail'";
			$result = mysqli_query($conn,$sql);
			$resultcheck = mysqli_num_rows($result);

			if ($resultcheck <= 0 && $resultcheckadmin <= 0 ) {

				echo "<script>alert('Wrong email or password.Please try again.');</script>";
				die("<script>window.location.href='../login.php'</script>");
						echo $resultcheck;
						echo "<br/>";
						echo $resultcheckadmin;
			}else{
				if($resultcheck >= 1 || $resultcheckadmin >=1){
						if($row = mysqli_fetch_assoc($result)){						
							//De-hash the password
							$hashedpasswordcheck = password_verify($upsw, $row['user_password']);
							if ($hashedpasswordcheck == false) {
								echo "<script>alert('Wrong email or password.Please try again.');</script>";
								die  ("<script>window.location.href='../login.php'</script>");
								echo $row['user_name'];
								echo "<br/>";
								echo $upsw;
								echo $resultcheck;
								echo $resultcheckadmin;
		
							}elseif($hashedpasswordcheck == true){
								//Log in the user
								$_SESSION['uemail'] = $row['user_email'];
								$_SESSION['uname'] = $row['user_name'];
								$_SESSION['uid'] = $row['user_id'];
								echo "<script>alert('Login successfully.');</script>";
								die("<script>window.location.href='../default.php?popup=1'</script>");
		
							}
						}elseif ($rows = mysqli_fetch_assoc($resultadmin)){
							if($upsw == $rows['admin_password']) {
								//Log in as Admin
								$_SESSION['aemail'] = $rows['admin_email'];
								$_SESSION['aname'] = $rows['admin_name'];
								$_SESSION['aid'] = $rows['admin_id'];
								echo "<script>alert('Logged In As Admin.');</script>";
								die("<script>window.location.href='../admin.php'</script>");
							}
						}
				} else {
						echo "<script>alert('Wrong email or password.Please try again.');</script>";
						die  ("<script>window.location.href='../login.php'</script>");

				}
			}
		}
	}else{
					echo "<script>alert('use the submit button');</script>";
					die("<script>window.location.href='../login.php'</script>");
					}
			

	



?>