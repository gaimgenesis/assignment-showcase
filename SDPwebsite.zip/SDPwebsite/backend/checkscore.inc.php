<?php
session_start();
include_once "connect.php";
 
	$user = (int)$_POST['scores'];
	// $score = (int)$_SESSION['score'];
	// $scoreboard = $score+$user;
	$id = $_POST['id'];
	$totalquestion = $_POST['total'];
	$_SESSION['total'] = $totalquestion;
	$gid = $_SESSION['gameid'];
	$next = (int)$_POST['question'];
	$question = (int)$next + 1;

	$sql = "Select * from game_result where game_result_id = $gid";
	$result = mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)<=0)
	{
		echo "No results.";
	}
	while($row=mysqli_fetch_array($result))
	{
		$currentscore = (int)$row['game_result_score'];
	}

	$newscore = $currentscore + $user;
	// echo $newscore;

	$sql2 = "Update game_result SET game_result_score = '$newscore'";
	
	mysqli_query ($conn,$sql2);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		// echo "<script>alert('No data updated in the DB');</script>";
		//die("<script>window.location.href='edit.php?id=$id'</script>");
	}
	if($question <= $totalquestion){
		echo "<script>window.location.href='../gamequestion.php?id=$id&question_no=$question';</script>";
	}
	echo "<script>window.location.href='../result.php';</script>";
	// echo $sql2;
?>