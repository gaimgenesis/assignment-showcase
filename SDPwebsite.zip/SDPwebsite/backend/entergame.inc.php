<?php
session_start();
include_once "connect.php";
// echo $_POST['uid'];
// echo $_POST['gid'];
$opponent = $_POST['userid'];
$uid = $_POST['currentuser'];
$gid = $_POST['gameid'];
$sql = "Insert into user_game (user_game_date, game_id_fk, user_id_fk,notification,Opponent) VALUES (now(),'$gid','$uid','1','$opponent')";
	
	if (mysqli_query($conn, $sql))
	{
		$last_id = mysqli_insert_id($conn);
	}else{
		echo "<script>alert('Unable to enter!');</script>";
		die ("<script>window.history.go(-1);</script>");
	}
	$time = date("h:i:s");

$sql3 = "Insert into game_result (game_result_time,user_game_id_fk) VALUES ('$time','$last_id')";
if (mysqli_query($conn, $sql3))
	{
		$lastid = mysqli_insert_id($conn);
		$_SESSION['gameid'] = $lastid;
	}else{
		echo "<script>alert('Unable to enter!');</script>";
		die ("<script>window.history.go(-1);</script>");
	}

	echo "<script>window.location.href='../gamequestion.php?id=$gid';</script>";	

?>