<?php 

session_start();

if (isset($_POST['submit'])) {

	include_once "connect.php";

	$oldpsw = mysqli_real_escape_string($conn, $_POST['oldpsw']);
	$newpsw = mysqli_real_escape_string($conn, $_POST['newpsw']);
	$confnewpsw = mysqli_real_escape_string($conn, $_POST['confnewpsw']);

	//Error handlers
	//Check for empty fields

	if (empty($oldpsw) || empty($newpsw) || empty($confnewpsw)) {

		echo "<script>alert('Please fill up all the required fields.');</script>";
		die("<script>window.location.href= '../accountSetting.php'</script>");
		
	}else{
		//fetch password from database
		$sql = "SELECT user_password FROM user WHERE user_email='{$_SESSION['uemail']}'";
		$result = mysqli_query($conn, $sql);
		$resultcheck = mysqli_num_rows($result);

		if ($resultcheck <= 0 ) {

		echo "<script>alert('Something is wrong with session?');</script>";
		die("<script>window.location.href= '../default.php'</script>");
		
		}else{
				//compare $oldpsw with password in database
				if ($row = mysqli_fetch_assoc($result)) {

					//De-hash the password
					$hashedpasswordcheck = password_verify($oldpsw, $row['user_password']);

					if ($hashedpasswordcheck == false) {

						echo "<script>alert('Old password is wrong.Please try again.');</script>";
						die  ("<script>window.location.href='../accountSetting.php'</script>");

					}elseif($hashedpasswordcheck == true){
						//Check if the new password match 
						if ($newpsw !== $confnewpsw) {

							echo "<script>alert('New password does not match.');</script>";
							die  ("<script>window.location.href='../accountSetting.php'</script>");

						}else{

							$newuhashedpsw = password_hash($newpsw, PASSWORD_DEFAULT);
							$sql = "UPDATE user SET user_password='$newuhashedpsw' WHERE user_email='{$_SESSION['uemail']}'";
							mysqli_query($conn, $sql);

							echo "<script>alert('Password Changed Successfully.');</script>";
							die  ("<script>window.location.href='../profile.php'</script>");

						}

					}

				}
			}
		}


}else{
	echo "<script>alert('Please use the submit button');</script>";
	die("<script>window.location.href='../changepassword.php'</script>");
  }

?>