<?php 
session_start();
$topic = $_POST['topic'];
$aid = $_SESSION['aid'];

include_once "connect.php";

$sql = "Insert into game (game_name,admin_id_fk) VALUES('$topic','$aid');";
mysqli_query($conn, $sql); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('Game has already been created!');window.history.go(-1);</script>");
}
$sql2 = "Select * from game where game_name = '$topic'";
$result = mysqli_query($conn, $sql2); 
if(mysqli_num_rows($result)<=0) //no result
	{
		die("<script>alert('No data found in the DB!');</script>");
	}
	
	if($rows = mysqli_fetch_array($result)) //if got result
	{	
		$_SESSION['gameid'] = $rows['game_id'];
		$gamename = $rows['game_name'];
	}
echo "<script>alert('Game Topic Inserted!')</script>";
echo "<script>window.location.href='../addgamequestion.php';</script>";
?>