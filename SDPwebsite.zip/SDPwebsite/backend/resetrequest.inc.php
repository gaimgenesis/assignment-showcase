<?php 

if (isset($_POST['submit'])) {
	//generate token, use bin2hax and random bytes to make the token secure.
	//$token is not converted to hex here because want to store bin in database.
	$selector = bin2hex(random_bytes(8));
	$token = random_bytes(32);

	//This url will be included in the email. URL is attached with token.
	$url = "http://localhost/sdpwebsite/createnewpassword.php?selector=" .$selector. "&validator=" .bin2hex($token);

	//Create an expiry for the token. 'U' is today date in second. 
	$expires = date("U") + 1800;

	require 'connect.php';

	$userEmail = $_POST['email'];

	//delete any existing token if there is one already
	$sql = "DELETE FROM pwdReset WHERE pwdResetEmail=?;";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {

		echo "<script>alert('There was an error.');</script>";
		die  ("<script>window.location.href='../resetpassword.php'</script>");

	}else{

		mysqli_stmt_bind_param($stmt, "s", $userEmail);
		mysqli_stmt_execute($stmt);
	}

	//Insert the data into database
	$sql = "INSERT INTO pswReset (pwdResetEmail, pwdResetSelector, pwdResetToken, pwdResetExpires) VALUES (?, ?, ?, ?);";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {

		echo "<script>alert('There was an error.');</script>";
		die  ("<script>window.location.href='../resetpassword.php'</script>");	

	}else{

		$hashedToken = password_hash($token, PASSWORD_DEFAULT);
		mysqli_stmt_bind_param($stmt, "ssss" ,$userEmail, $selector, $hasedToken, $expires);
		mysqli_stmt_execute($stmt);

	}

	mysqli_stmt_close($stmt);
	mysqli_close($conn);


	//Start writing email to user
	$to = $userEmail;

	$subject = 'Reset your password for Elevate Academy';

	$message = '<p>We received a password reset request. Click the link below to reset your password. If you did not make any request, you can ignore this email.</p>';
	$message .= '<p>Here is your password reset link: <br/>';
	$message .= '<a href=" '.$url.' ">' .$url. '</a></p>';

	$headers = "From: Elevate Academy <elevateacademy@gmail.com> \r\n";
	$headers .= "Reply-To: elevateacademy@gmail.com \r\n";
	$headers .= "Content-type: text/html\r\n";

	mail($to, $subject, $message, $headers);

	echo "<script>alert('The reset password link has been sent to your email');</script>";
	die("<script>window.location.href='../resetpassword.php?reset=success'</script>");


}else{

	echo "<script>alert('Please use the send button');</script>";
	die("<script>window.location.href='../resetpassword.php'</script>");

}
