<?php
session_start();
include_once "connect.php";
 
	$user = (int)$_POST['scores'];
	// $score = (int)$_SESSION['score'];
	// $scoreboard = $score+$user;
	$id = $_POST['id'];
	$totalquestion = $_POST['total'];
	$_SESSION['total'] = $totalquestion;
	$qid = $_SESSION['quizid'];
	$next = (int)$_POST['question'];
	$question = (int)$next + 1;
	// echo $qid;
	// echo $user;
	// echo "<br/>";
	// echo $id;
	// echo "<br/>";

	// echo $qid;
	// echo "<br/>";

	$sql = "Select * from quiz_result where quiz_result_id = $qid ";
	// echo $sql;
	$result = mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)<=0)
	{
		echo "No results.";
	}
	while($row=mysqli_fetch_array($result))
	{
		$currentscore = (int)$row['quiz_result_score'];
	}
	// echo $currentscore;
	$newscore = $currentscore + $user;
	// echo $newscore;
	// echo $newscore;

	$sql2 = "Update quiz_result SET quiz_result_score = '$newscore' where quiz_result_id = $qid";
	
	mysqli_query ($conn,$sql2);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		// echo "<script>alert('No data updated in the DB');</script>";
		// die("<script>window.location.href='edit.php?id=$id'</script>");
	}
	if($question <= $totalquestion){
		echo "<script>window.location.href='../quizquestion.php?id=$id&question_no=$question';</script>";
	}
	echo "<script>window.location.href='../quizresult.php';</script>";
	// echo $sql2;
?>