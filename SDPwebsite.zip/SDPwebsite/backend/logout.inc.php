<?php 
session_start();

if (isset($_POST['submit'])) {
	session_unset();
	session_destroy();
	echo "<script>alert('Logout Successfully.');</script>";
	die  ("<script>window.location.href='../login.php'</script>");
}

?>