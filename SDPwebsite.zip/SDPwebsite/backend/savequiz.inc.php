<?php
session_start();
include_once "connect.php";
$question = $_POST['question'];
$id = $_POST['id'];
$aid1 = $_POST['answerid1'];
$aid2 = $_POST['answerid2'];
$aid3 = $_POST['answerid3'];
$aid4 = $_POST['answerid4'];
$correct0 = $_POST['correctanswer1'];
$correct1 = $_POST['correctanswer2'];
$correct2 = $_POST['correctanswer3'];
$correct3 = $_POST['correctanswer4'];

$answer0 = $_POST['ans1'];
$answer1 = $_POST['ans2'];
$answer2 = $_POST['ans3'];
$answer3 = $_POST['ans4'];

/*echo $questionname;
echo $aid1;
echo $aid2;
echo $aid3;
echo $aid4;
echo $correct0;
echo $correct1;
echo $correct2;
echo $correct3;
echo $answer0;
echo $answer1;
echo $answer2;
echo $answer3;*/
$sql = "Update quiz_answer SET quiz_answer = '$answer0', correct_answer = '$correct0' WHERE quiz_answer_id = $aid1";
	
	//run query
	mysqli_query ($conn,$sql);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		//echo "<script>alert('No data updated in the DB');</script>";
		//die("<script>window.location.href='editquiz.php?id=$id'</script>");
		//echo $sql;
	}
$sql2 = "Update quiz_answer SET quiz_answer = '$answer1', correct_answer = '$correct1' WHERE quiz_answer_id = $aid2";
	
	//run query
	mysqli_query ($conn,$sql2);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		//echo "<script>alert('No data updated in the DB');</script>";
		//die("<script>window.location.href='editquizs.php?id=$id'</script>");
		//echo $sql2;
	}
$sql3 = "Update quiz_answer SET quiz_answer = '$answer2', correct_answer = '$correct2' WHERE quiz_answer_id = $aid3";
	
	//run query
	mysqli_query ($conn,$sql3);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		//echo "<script>alert('No data updated in the DB');</script>";
		//die("<script>window.location.href='editquizs.php?id=$id'</script>");
		//echo $sql3;
	}
$sql4 = "Update quiz_answer SET quiz_answer = '$answer3', correct_answer = '$correct3' WHERE quiz_answer_id = $aid4";
	
	//run query
	mysqli_query ($conn,$sql4);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		//echo "<script>alert('No data updated in the DB');</script>";
		//die("<script>window.location.href='editquizs.php?id=$id'</script>");
		//echo $sql4;
	}			
	echo "<script>alert('Data updated in DB');</script>";
	die("<script>window.location.href='../editquiz.php?id=$id'</script>");

?>