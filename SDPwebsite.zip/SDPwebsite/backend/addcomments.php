<?php
session_start();
include_once 'connect.php';


		$userid = mysqli_real_escape_string($conn,$_POST['userid']);
		$id = mysqli_real_escape_string($conn,$_POST['qid']);
		echo $id;
		$text = mysqli_real_escape_string($conn,$_POST['commenttext']);
		$pageid = mysqli_real_escape_string($conn,$_POST['pageid']);
		$pagename= mysqli_real_escape_string($conn,$_POST['directpage']);
		if ($text ==NULL){
			echo "<script>alert('Comment cannot be empty')</script>";
			die ("<script>window.history.go(-1);</script>");

		}
		$sql = "INSERT into quiz_comments (quiz_comment, quiz_comment_date, user_id_fk, quiz_question_id_fk) Values ('".$text."',  NOW(),'".$userid."', '".$id."')";
		// echo $sql;
		mysqli_query($conn,$sql);
		if(mysqli_affected_rows($conn)<=0)
		{
			die("<script>alert('Error posting comments. Please try again.');</script>");
		}
		echo $sql;
		die ("<script>alert('Comments Inserted!');window.history.go(-1);</script>");
echo "<script>window.location.href='window.history.go(-1)';</script>";


?>