<?php 

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "elevate_academy";

$conn = mysqli_connect($servername, $username, $password, $databasename);
 
?>