<?php 
if (isset($_POST['submit'])) {

	include_once 'connect.php';

	$uname = mysqli_real_escape_string($conn, $_POST['username']);
	$uemail = mysqli_real_escape_string($conn, $_POST['email']);
	$upsw = mysqli_real_escape_string($conn, $_POST['psw']);
	$upswcf = mysqli_real_escape_string($conn, $_POST['pswcomfirm']);

	//Error handlers
	//Check for empty fields
	if(empty($uname) || empty($uemail) || empty($upsw) ){

		echo "<script>alert('Please fill up all the fields.');</script>";
		die  ("<script>window.location.href='../register.php'</script>");

	}else{
		//check if input characters are valid
		if (!preg_match("/^[a-zA-Z0-9]*$/", $uname)) {

			echo "<script>alert('Invalid username.');</script>";
			die("<script>window.location.href='../register.php'</script>");

		}else{
			//check if email is valid
			if (!filter_var($uemail, FILTER_VALIDATE_EMAIL)) {
				
				echo "<script>alert('Invalid email.');</script>";
				die("<script>window.location.href='../register.php'</script>");					

			}else{
				//check if the email is taken
				$sql = "SELECT * FROM user WHERE user_email='$uemail';";
				$result = mysqli_query($conn, $sql);
				$resultcheck = mysqli_num_rows($result); 

				if ($resultcheck>0) {

					echo "<script>alert('Email is registered before.');</script>";		
					die("<script>window.location.href=' ../register.php'</script>");			
					
				}else{
					//check if both passwords are matched.
					if($upsw != $upswcf){

						echo "<script>alert('Password does not match with comfirm password.');</script>";		
						die("<script>window.location.href=' ../register.php'</script>");	

					}else{
						//Hash the password
						$uhashedpsw = password_hash($upsw, PASSWORD_DEFAULT);
						//Insert the user into database
						$sql = "INSERT INTO user (user_email, user_password, user_name) VALUES ('$uemail', '$uhashedpsw', '$uname');";

						mysqli_query($conn, $sql);

						//Insert a status to indicate that this user exist, but does not have a profile picture yet.
						$sql2 = "SELECT * FROM user WHERE user_email = '$uemail'";
						$result2 = mysqli_query($conn,$sql2);

							if (mysqli_num_rows($result2) > 0) {
								while ($row = mysqli_fetch_assoc($result2)) {
									$userid = $row['user_id'];
									$sql3 = "INSERT INTO profileimg (user_id_fk, status) VALUES ('$userid',1)"; 
									mysqli_query($conn,$sql3);
								}

							} else {
								echo "user does not exist.";
							}

						echo "<script>alert('Register Successfully!');</script>";
						die  ("<script>window.location.href='../login.php'</script>");
					}

				}

			}


		}


	}


}else{
	echo "<script>alert('use the submit button');</script>";
	die  ("<script>window.location.href=' ../register.php'</script>");
}

 ?>