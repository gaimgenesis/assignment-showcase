<?php
session_start();
include_once "connect.php";
// echo $_POST['uid'];
// echo $_POST['gid'];
$uid = $_POST['currentuser'];
$gid = $_POST['gameid'];
// $gdate = $_POST['gamedate'];
// $gameid = $_POST['usergame'];
$opid = $_POST['opid'];
$sql = "Insert into user_game (user_game_date, game_id_fk, user_id_fk,notification,Opponent) VALUES (now(),'$gid','$opid','0','$uid')";
	
	if (mysqli_query($conn, $sql))
	{
		$last_id = mysqli_insert_id($conn);
	}else{
		echo "<script>alert('Unable to enter!');</script>";
		//die ("<script>window.history.go(-1);</script>");
	}
	$time = date("h:i:s");
$sql3 = "Insert into game_result (game_result_time,user_game_id_fk) VALUES ('$time','$last_id')";
if (mysqli_query($conn, $sql3))
	{
		$lastid = mysqli_insert_id($conn);
		$_SESSION['gameid'] = $lastid;
	}else{
		echo "<script>alert('Unable to enter!');</script>";
		die ("<script>window.history.go(-1);</script>");
	}
$sql2 = "UPDATE user_game SET notification = '0' where user_game_id = $gid";
//echo $sql2;
	mysqli_query ($conn,$sql2);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		//echo "<script>alert('No data updated in the DB');</script>";
		
	}
	echo "<script>window.location.href='../gamequestion.php?id=$gid';</script>";	

?>