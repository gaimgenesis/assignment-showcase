<?php 

session_start();

if (isset($_POST['submit'])) {

	include_once "connect.php";

	$oldusn = mysqli_real_escape_string($conn, $_POST['oldusn']);
	$newusn = mysqli_real_escape_string($conn, $_POST['newusn']);

	//Error handlers
	//Check for empty fields

	if (empty($oldusn) || empty($newusn)) {

		echo "<script>alert('Please fill up all the required fields.');</script>";
		die("<script>window.location.href= '../accountSetting.php'</script>");
		
	}else{
		//fetch password from database
		$sql = "SELECT user_name FROM user WHERE user_email='{$_SESSION['uemail']}'";
		$result = mysqli_query($conn, $sql);
		$resultcheck = mysqli_num_rows($result);

		if ($resultcheck <= 0 ) {

		echo "<script>alert('Something is wrong with session?');</script>";
		die("<script>window.location.href= '../default.php'</script>");
		
		}else{
				//compare $oldpsw with password in database
				if ($row = mysqli_fetch_assoc($result)) {

							$newuhashedusername = $newusn;
							$sql = "UPDATE user SET user_name='$newuhashedusername' WHERE user_email='{$_SESSION['uemail']}'";
							mysqli_query($conn, $sql);
							$_SESSION['uname'] = $newusn;
							echo "<script>alert('Username Changed Successfully.');</script>";
							die  ("<script>window.location.href='../profile.php'</script>");

						}

					}

				}



}else{
	echo "<script>alert('Please use the submit button');</script>";
	die("<script>window.location.href='../changepassword.php'</script>");
  }

?>