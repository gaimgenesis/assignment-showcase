<?php
	include_once "connect.php";
	session_start();
	$id = $_POST['id'];
	// echo $id;
	// echo "<br/>";
	$score = $_POST['score'];
	// echo $score;
	// echo "<br/>";
	// $sql = ""
	$sql = "UPDATE game_result SET game_result_point = '$score' where game_result_id = $id";
	mysqli_query ($conn,$sql);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		echo "<script>alert('No data updated in the DB');</script>";
		//die("<script>window.location.href='edit.php?id=$id'</script>");
	}
	// echo $sql;
	// echo "<br/>";
	$sql1 = "SELECT * from game_result LEFT JOIN user_game on user_game_id = user_game_id_fk LEFT JOIN user on user_id = user_id_fk";
	$result = mysqli_query($conn,$sql1);
	if(mysqli_num_rows($result)<=0)
  {
    echo "Cannot store results.";
  }
  while($row=mysqli_fetch_array($result))
  {
  	$userpoints = $row['user_honour_points'];
  	$userid = $row['user_id'];
  }
  $newscore = (int)$userpoints + (int)$score;
  // echo $newscore;
  // echo $sql1;
  	$sql2 = "UPDATE user SET user_honour_points = '$newscore' where user_id = '$userid'";
  	mysqli_query ($conn,$sql2);
	
	if(mysqli_affected_rows($conn)<=0)
	{
		// echo "<script>alert('No data updated in the DB');</script>";
		//die("<script>window.location.href='edit.php?id=$id'</script>");
	}
	die("<script>window.location.href='../games.php'</script>");	
?>