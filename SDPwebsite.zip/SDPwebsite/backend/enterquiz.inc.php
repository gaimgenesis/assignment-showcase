<?php
session_start();
include_once "connect.php";
// echo $_POST['uid'];
// echo $_POST['gid'];
$uid = $_POST['uid'];
$qid = $_POST['qid'];
echo $qid;
$sql = "Insert into user_quiz (user_quiz_date, quiz_id_fk, user_id_fk) VALUES (now(),'$qid','$uid')";
	
	if (mysqli_query($conn, $sql))
	{
		$last_id = mysqli_insert_id($conn);
	}else{
		echo "<script>alert('Unable to enter!');</script>";
		die ("<script>window.history.go(-1);</script>");
	}
	$time = date("h:i:s");

$sql3 = "Insert into quiz_result (quiz_result_time,user_quiz_id_fk) VALUES ('$time','$last_id')";
if (mysqli_query($conn, $sql3))
	{
		$lastid = mysqli_insert_id($conn);
		$_SESSION['quizid'] = $lastid;
	}else{
		echo "<script>alert('Unable to enter!');</script>";
		die ("<script>window.history.go(-1);</script>");
	}

	echo "<script>window.location.href='../quizquestion.php?id=$qid';</script>";	

?>