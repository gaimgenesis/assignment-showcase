<?php 

if (isset($_POST['submit'])) {
	
	$selector = $_POST['selector'];
	$validator = $_POST['validator'];
	$psw = $_POST['psw'];
	$confpsw = $_POST['confpsw'];

	//check if the fields are empty
	if(empty($psw) || empty($confpsw)) {

		echo "<script>alert('Please fill up all the required fields.');</script>";
		die  ("<script>window.location.href='../createnewpassword.php?newpsw=empty'</script>");

	} else if($psw !== $confpsw){

		echo "<script>alert('New password does not match.');</script>";
		die  ("<script>window.location.href='../createnewpassword.php?newpsw=mismatch'</script>");
	}

	//Check if the the token is expired
	$currentDate = date("U");

	include 'connect.php';

	$sql = "SELECT * FROM pwdreset WHERE pwdResetSelector=? AND pwdResetExpires >= $currentDate";

	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt,$sql)) {

		echo "<script>alert('Something is wrong.Please try again later');</script>";
		die  ("<script>window.location.href='../createnewpassword.php?stmt=error'</script>");
	} else{

		mysqli_stmt_bind_param($stmt, "s", $selector);
		mysqli_stmt_execute($stmt);

		$result = mysqli_stmt_get_result($stmt)
		if (!$row = mysqli_fetch_assoc($result)) {
			
			echo "<script>alert('You need to re-submit your reset password.');</script>";
			die  ("<script>window.location.href='../createnewpassword.php?stmt=error'</script>");
		} else{
			//convert the token back to binary and check if its match with db value.
			$tokenBin = hex2bin($validator);
			$tokenCheck = password_verify($tokenBin, $row['pwdResetToken']);

			if ($tokenCheck === false) {
				
				echo "<script>alert('You need to re-submit your reset request.');</script>";
				die  ("<script>window.location.href='../resetpassword.php?stmt=error'</script>");			

			} else if ($tokenCheck === true){

				$tokenEmail = $row['pwdResetEmail'];

				//check if the user is indeed exist inside db, then pinpoint.
				$sql = "SELECT * FROM user WHERE user_email=?;";
				$stmt = mysqli_stmt_init($conn);
				if (!mysqli_stmt_prepare($stmt, $sql)) {
					
					echo "<script>alert('Something is wrong.Please try again later');</script>";
					die  ("<script>window.location.href='../createnewpassword.php?stmt=error'</script>");
				} else {

					mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
					mysqli_stmt_execute($stmt);

					$result = mysqli_stmt_get_result($stmt);

					if (!$row = mysqli_fetch_assoc($result)) {

						echo "<script>alert('There was an error. Please try again later.');</script>";
						die  ("<script>window.location.href='../createnewpassword.php?stmt=error'</script>");
					}else{

						//update user password
						$sql = "UPDATE user SET user_password=? WHERE user_email=?;";

						$stmt = mysqli_stmt_init($conn);
						if (!mysqli_stmt_prepare($stmt, $sql)) {
					
						echo "<script>alert('Something is wrong.Please try again later');</script>";
						die  ("<script>window.location.href='../createnewpassword.php?stmt=error'</script>");
						} else {

							$newpswhashed = password_hash($psw, PASSWORD_DEFAULT);

							mysqli_stmt_bind_param($stmt, "ss", $newpswhashed, $tokenEmail);
							mysqli_stmt_execute($stmt);

							//delete the token as we dont want it to further exist.
							$sql = "DELETE FROM pwdReset WHERE pwdResetEmail=?;";
							$stmt = mysqli_stmt_init($conn);
							if (!mysqli_stmt_prepare($stmt, $sql)) {

								echo "<script>alert('There was an error.');</script>";
								die  ("<script>window.location.href='../login.php?newpsw=updatedSuccessfully'</script>");

							}else{

								mysqli_stmt_bind_param($stmt, "s", $userEmail);
								mysqli_stmt_execute($stmt);
							}
						}

					}
			}

		}
	}


} else{

	echo "<script>alert('Please use the submit button.');</script>";
	die  ("<script>window.location.href='../default.php'</script>");

}


?>