<?php
session_start();
$question = $_POST['question'];
$answers1 = $_POST['answers1'];
$answers2 = $_POST['answers2'];
$answers3 = $_POST['answers3'];
$answers4 = $_POST['answers4'];
$answer1 = $_POST['answername1'];
$answer2 = $_POST['answername2'];
$answer3 = $_POST['answername3'];
$answer4 = $_POST['answername4'];
$gameid = $_SESSION['gameid'];

include_once "connect.php";

$sql0 = "Insert into game_question (game_question, game_id_fk) VALUES ('$question','$gameid');";
mysqli_query($conn, $sql0); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('game has already been created!');</script>");
}
$sql = "Select * from game_question where game_question = '$question'";
$result = mysqli_query($conn, $sql); 
if(mysqli_num_rows($result)<=0) //no result
	{
		die("<script>alert('No data found in the DB!');</script>");
	}
	
	if($rows = mysqli_fetch_array($result)) //if got result
	{	
		$questionid = $rows['game_question_id'];
	}
$sql1 = "Insert into game_question_answer (game_answer, game_question_id_fk, correct_answer, game_id_fk) VALUES ('$answer1','$questionid','$answers1','$gameid');";
mysqli_query($conn, $sql1); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('game has already been created!');</script>");
}
$sql2 = "Insert into game_question_answer (game_answer, game_question_id_fk, correct_answer, game_id_fk) VALUES ('$answer2','$questionid','$answers2','$gameid');";
mysqli_query($conn, $sql2); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('game has already been created!');</script>");
}
$sql3 = "Insert into game_question_answer (game_answer, game_question_id_fk, correct_answer, game_id_fk) VALUES ('$answer3','$questionid','$answers3','$gameid');";
mysqli_query($conn, $sql3); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('game has already been created!');</script>");
}
$sql4 = "Insert into game_question_answer (game_answer, game_question_id_fk, correct_answer, game_id_fk) VALUES ('$answer4','$questionid','$answers4','$gameid');";
mysqli_query($conn, $sql4); 
if(mysqli_affected_rows($conn) <=0)
{
	die("<script>alert('game has already been created!');</script>");
}
echo "<script>alert('Game Question Inserted!')</script>";
echo "<script>window.location.href='../addgamequestion.php';</script>";

?>