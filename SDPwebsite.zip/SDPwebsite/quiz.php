﻿<?php
include "backend/connect.php";
if (isset($_GET['page_no']) && $_GET['page_no']!="") {
    $page_no = $_GET['page_no'];
    } else {
        $page_no = 1;
        }
        $total_records_per_page = 5;
$offset = ($page_no-1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = "2";
$result_count = mysqli_query(
$conn,
"SELECT COUNT(*) As total_records FROM quiz"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1; // total pages minus 1

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" type="text/css" href="css/login.css" />
<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/menu.css"/>
<link rel="stylesheet" type="text/css" href="css/search.css"/>
<script type="text/javascript" src="js/header.js"></script>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>


<meta name="viewport" content="width=device-width, initial-scale=1"/>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<title>Quiz</title>

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}
</style>
</head>

<body>

<!--- header ----->
<?php 

include_once 'template/header.php';

?>
<!----/header ---->


<!--------------Search bar ----------------->
<div style='width: 95vw;margin: 0 auto' >
<p style="color: black; font-size: 30px; padding-left: 12px;">Quiz List </p>

<div class="searchicon">
  <form method="post" action="">
       <input type="text" name="search_key" required="required" class="searchinput" placeholder="Search"/>
      <button type="submit" class="searchbtn"><i class="fa fa-search"></i></button>
  </form>
</div>
<br/>


  <!--result should display after the html form! so php code at here!-->
  <?php
    //step 1: connection    
    //step 2: check whether the search key already exist or not
    // if exist, the search key with the variable searchkey
    if(isset($_POST['search_key']))
    {
      //store the search key with the variable $searchkey
      $searchkey = $_POST['search_key'];
      
      //step 3: create search sql query
      $sql = "Select * from quiz where quiz_name LIKE '%$searchkey%';";
      $result = mysqli_query($conn, $sql);
      
      if(mysqli_num_rows($result)<=0)
      {
        echo "<script>alert('No topic found!');</script>";
      }
      
      echo "<table id='quiztopic'>";
      echo "<thead>";
      echo "<tr>";
      echo "<th style='width: 75vw'>Topic Name</th>";
      echo "<th></th>";
      echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
    $quizids = array();
    $quiznames = array();
      while($row = mysqli_fetch_assoc($result))
          {
    array_push($quizids, $row['quiz_id']);
    array_push($quiznames, $row['quiz_name']);
          }

        $c = sizeof($quizids);
        //echo $c;
        for ($i=0; $i<$c;$i++)
        {
          echo "<tr>";
          echo "<td>$quiznames[$i]</td>";
          echo "<td>";
          echo "<button class='play play1' onclick='pop".$i."()'>Play</button></td>";         
          echo "</tr>";
          echo "<div class='popup' id='pop".$i."' onclick='closepop()'><div class='popup-contnet'><br/><center><h2>Are you sure you wants to enter the quiz?</h2></center><br/><form method='POST' action='backend/enterquiz.inc.php'><input type='hidden' name='qid' value='".$quizids[$i]."'/><input type='hidden' name='uid' value='".$_SESSION['uid']."'/>";
  echo "<button type='submit' class='play play1'>Play</button></a></form></div></div>";

        }

    echo "</table>";
    }
  ?>
</tbody>

</table>
<center>
<table id="quiztopic">
<thead>
<tr>
<th style="width: 75vw">Topic Name</th>
<th></th>
</tr>
</thead>
<tbody>

<script>
  function pop1() {

    document.getElementById('pop1').style.display = 'block';
  }
  function pop2() {

  document.getElementById('pop2').style.display = 'block';
  }
  function pop3() {

  document.getElementById('pop3').style.display = 'block';
  }
  function pop4() {

   document.getElementById('pop4').style.display = 'block';
  }
  function pop0() {

  document.getElementById('pop0').style.display = 'block';
}

  function closepop() {
    document.getElementById('pop0').style.display = 'none';
    document.getElementById('pop1').style.display = 'none';
    document.getElementById('pop2').style.display = 'none';
    document.getElementById('pop3').style.display = 'none';
    document.getElementById('pop4').style.display = 'none';
  }
</script>
<?php
$result = mysqli_query(
    $conn,
    "SELECT * FROM quiz LIMIT $offset, $total_records_per_page"
    );
    $quizid = array();
    $quizname = array();
while($row = mysqli_fetch_array($result))
        {
    array_push($quizid, $row['quiz_id']);
    array_push($quizname, $row['quiz_name']);
        }

        $c = sizeof($quizid);
        //echo $c;
        for ($i=0; $i<$c;$i++)
        {
          echo "<tr>";
          echo "<td>$quizname[$i]</td>";
          echo "<td>";
          echo "<button class='play play1' onclick='pop".$i."()'>Play</button></td>";         
          echo "</tr>";
          echo "<div class='popup' id='pop".$i."' onclick='closepop()'><div class='popup-contnet'><br/><h2>Are you sure you wants to enter the quiz?</h2><br/><form method='POST' action='backend/enterquiz.inc.php'><input type='hidden' name='qid' value='".$quizid[$i]."'/><input type='hidden' name='uid' value='".$_SESSION['uid']."'/>";
  echo "<button type='submit' class='play play1'>Play</button></a></form></div></div>";

        }

mysqli_close($conn);
?>
</tbody>


</table></center>
<br/><br/>
<div class="pagination">
<?php if($page_no <= 1){ echo ""; } ?>
<a <?php if($page_no > 1){
echo "href='?page_no=$previous_page'";
} ?> style="cursor: pointer">Previous</a>
    
<?php if($page_no >= $total_no_of_pages){
echo "";
} ?>
<a <?php if($page_no < $total_no_of_pages) {
echo "href='?page_no=$next_page'";
} ?> style="cursor: pointer">Next</a>
 

</div>
</div>

<!--------------Footer ----------------->
<?php  
include_once 'template/footer.php';
?>

<!--------------/footer------------------>


</body>

</html>
