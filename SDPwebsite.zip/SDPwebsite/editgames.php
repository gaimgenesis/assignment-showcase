<?php

$id = $_GET['id'];

include "backend/connect.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />

<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/menu.css"/>
<link rel="stylesheet" type="text/css" href="css/quiz.css"/>
<script type="text/javascript" src="js/header.js"></script>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1"/>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}
.answersform {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}
.text, select{
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.ans, select{
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.save {
  width: 40%;
  background-color: grey;
  border-color: black;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  font-size: 20px;
  font-weight: bolder;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.save:hover {
  background-color: lime;
}
.back {
  width: 40%;
  background-color: orange;
  border-color: black;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  font-size: 20px;
  font-weight: bolder;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

.back:hover {
  background-color: red;
}
/*.navbar-inverse .navbar-nav .dropdown-menu li a:hover {
  background: #2C463C;
} */


</style>

<title>Edit Game</title>
</head>


<body>

<!--- header ----->
<?php 

include_once 'template/header.php';

?>
<!-----/header---->
<div class="answersform">
<form action="" method="POST">
<h2>Edit Questions</h2>
<br/>
<div class="answersform">
<form action="" method="POST" class="none">
<select name="questionnumber" class="none">
<option value="Pick a question please :(">Select Game Question Number</option>
<?php
$sql3 = "Select * from game_question where game_id_fk = '$id'";
$result3 = mysqli_query($conn, $sql3);
if(mysqli_num_rows($result3)<=0)
{
  echo "<script>alert('No questions found! :(');</script>";
}
while($rows = mysqli_fetch_array($result3))
{
    echo "<option value='".$rows['game_question_id']."'>".$rows['game_question_id']."</option>";
}
?>
</select>
<input type="submit" class="search" name="search" value="Search"/>
<br/>
</form>
<form action="backend/savegame.inc.php" method="POST">
<?php
if(isset($_POST['questionnumber'])){
    $questionname = $_POST['questionnumber'];
    $sql = "Select * from game_question_answer where game_question_id_fk = $questionname";
    $sql0 = "Select * from game_question where game_question_id = $questionname";
    $result0 = mysqli_query($conn, $sql0);
    if(mysqli_num_rows($result0)<=0)
    {
      echo 'No answers found :(';
    }
    while($row = mysqli_fetch_array($result0))
    {
      $question = $row['game_question'];
    }
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)<=0)
    {
      echo 'No answers found :(';
    }
    while($row = mysqli_fetch_array($result))
    {
      $correct[] = $row['correct_answer'];
      $gameanswerid[] = $row['game_answer_id'];
      $gameanswer[] = $row['game_answer'];
    }?>
    <h3><?php echo $question;?></h3>
    <input type="hidden" name="question" value="<?php echo $question;?>"/>
    <input type="hidden" name="id" value="<?php echo $id;?>"/>
    <input type="hidden" name="questionid" value="<?php echo $questionname;?>"/>
    <input type="hidden" name="answerid1" value="<?php echo $gameanswerid[0];?>"/>
    <input type = "text" class="ans" id="ansname" name="ans1" value="<?php echo $gameanswer[0];?>" required="required">     <input type="hidden" name="correctanswer1" value="0" /><input type="checkbox" value="1" name="correctanswer1" <?php if($correct[0] == "1" ) echo"checked='checked'";?>/>Correct Answer
    <input type="hidden" name="answerid2" value="<?php echo $gameanswerid[1];?>"/>
    <input type = "text" class="ans" id="ansname" name="ans2" value="<?php echo $gameanswer[1];?>" required="required">     <input type="hidden" name="correctanswer2" value="0" /><input type="checkbox" value="1" name="correctanswer2" <?php if($correct[1] == "1" ) echo"checked='checked'";?>/>Correct Answer
    <input type="hidden" name="answerid3" value="<?php echo $gameanswerid[2];?>"/>
    <input type = "text" class="ans" id="ansname" name="ans3" value="<?php echo $gameanswer[2];?>" required="required">     <input type="hidden" name="correctanswer3" value="0" /><input type="checkbox" value="1" name="correctanswer3" <?php if($correct[2] == "1" ) echo"checked='checked'";?>/>Correct Answer
    <input type="hidden" name="answerid4" value="<?php echo $gameanswerid[3];?>"/>
    <input type = "text" class="ans" id="ansname" name="ans4" value="<?php echo $gameanswer[3];?>" required="required">     <input type="hidden" name="correctanswer4" value="0" /><input type="checkbox" value="1" name="correctanswer4"  <?php if($correct[3] == "1" ) echo"checked='checked'";?>/>Correct Answer
    
<?php
}
else{
}
?>
<br/>
<br/>
<input type="submit" class="save" value="Save Changes">
<input type="button" class="back" onclick="window.location.href='managegame.php';" value="Finish Editing Questions?"/>
</form>
</div>
</div>


<script type="text/javascript">
        // the selector will match all input controls of type :checkbox
// and attach a click event handler 
$("input:checkbox").on('click', function() {
  // in the handler, 'this' refers to the box clicked on
  var $box = $(this);
  if ($box.is(":checked")) {
    // the name of the box is retrieved using the .attr() method
    // as it is assumed and expected to be immutable
    var group = "input:checkbox[name='" + $box.attr("name") + "']";
    // the checked state of the group/box on the other hand will change
    // and the current value is retrieved using .prop() method
    $(group).prop("checked", false);
    $box.prop("checked", true);
  } else {
    $box.prop("checked", false);
  }
});
    </script>
<!--------------Footer ----------------->
<?php  
include_once 'template/footer.php';
?>

<!--------------/footer------------------>


</body>

</html>