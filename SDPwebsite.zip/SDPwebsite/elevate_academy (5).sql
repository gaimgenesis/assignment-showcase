-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 18, 2019 at 03:54 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elevate_academy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(12) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(20) NOT NULL,
  `admin_email` varchar(64) NOT NULL,
  `admin_password` varchar(20) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'test', 'test@gmail.com', '123'),
(2, 'DOUBLEE', 'doublee@gmail.com', 'qweqweqwe');

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
CREATE TABLE IF NOT EXISTS `game` (
  `game_id` int(12) NOT NULL AUTO_INCREMENT,
  `game_name` varchar(50) NOT NULL,
  `admin_id_fk` int(11) NOT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`game_id`, `game_name`, `admin_id_fk`) VALUES
(1, 'Circles', 1),
(2, 'Number Bases', 1),
(3, 'Probability', 1),
(4, 'Sets', 1),
(5, 'Quadratic Expressions', 1),
(6, 'Standard Form', 1),
(7, 'Straight Line', 1),
(8, 'Circles II', 1),
(10, 'Testing', 1),
(26, 'pewdiepie', 1),
(27, 'hola', 1),
(28, 'hola', 1),
(29, 'holy', 1),
(30, 'hello', 1),
(31, 'asdfghjkp', 1),
(32, 'try', 1),
(33, 'Test', 1);

-- --------------------------------------------------------

--
-- Table structure for table `game_question`
--

DROP TABLE IF EXISTS `game_question`;
CREATE TABLE IF NOT EXISTS `game_question` (
  `game_question_id` int(12) NOT NULL AUTO_INCREMENT,
  `game_question` longtext NOT NULL,
  `game_image` blob,
  `game_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`game_question_id`),
  KEY `game_id_fk` (`game_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_question`
--

INSERT INTO `game_question` (`game_question_id`, `game_question`, `game_image`, `game_id_fk`) VALUES
(2, 'Which of the folllowing is the correct standard form of 63.4?', NULL, 6),
(3, 'Which of the folllowing is the standard form of 2300?', NULL, 6),
(4, 'Round off 24632 to 3 significant numbers.', NULL, 6),
(5, 'Round off 0.007455 to 3 significant numbers.', NULL, 6),
(6, 'Calculate the value of 5.33 + 0.33 x 17 (3 significant figures).', NULL, 6),
(7, 'Calculate the value of 49.3567 + 16.73 / 0.5 (4 significant numbers).', NULL, 6),
(8, 'Find the value of 8.608 / 0.08 - 28.35 (3 significant figures).', NULL, 6),
(9, 'Express 23000 in standard form.', NULL, 6),
(10, 'Convert 110101 base 2 to a number in base 5', NULL, 2),
(11, 'Convert 43 base 5 to a number in base 2', NULL, 2),
(12, 'Convert 422 base 5 to a number in base 8', NULL, 2),
(13, 'Convert 10101 base 2 to a number in base 10', NULL, 2),
(14, 'Convert 61 base 10 into a number in base five', NULL, 2),
(15, 'Express 10000110 base 2 to a number in base 8', NULL, 2),
(16, 'Given h base 8 is equal to 10111 base 2, where h is an integer, find the value of h', NULL, 2),
(17, 'Express 2^6 + 2^4 + 1 as a number in base 2.', NULL, 2),
(18, 'State the value of digit 2 in the number of 32417 base 5 in a number of base 10.', NULL, 2),
(19, '10110 base 2 + 111 base 2 = ? ', NULL, 2),
(20, 'In a group of 80 prefects, 25 are girls. 10 boys leave the group. If a prefect is chosen at random, what is the probability that it is a boy prefect?', NULL, 3),
(21, 'A box has 5 red marbles and 21 blue marbles. Another 4 red and 1 blue marble was added into the box. What is the probability that a red marble will be chosen at random?', NULL, 3),
(22, 'A box has 36 green erasers and a number of red erasers. If the probability of picking a red eraser at random is 5/8. Find the number of red erasers.', NULL, 3),
(23, 'A box has blue and green marbles. The probability of picking a blue marble at random is 6/11. If there are 30 green marbles in the box, how many blue marbles are there?', NULL, 3),
(24, 'A box contains 5 red cards, 3 yellow cards and a number of green cards. A card is picked at random. If the probability of picking a yellow card is 1/6, what is the probability of picking a NON green card?', NULL, 3),
(27, 'testing', NULL, 30),
(28, 'ada', NULL, 32),
(29, 'Who is gay', NULL, 33);

-- --------------------------------------------------------

--
-- Table structure for table `game_question_answer`
--

DROP TABLE IF EXISTS `game_question_answer`;
CREATE TABLE IF NOT EXISTS `game_question_answer` (
  `game_answer_id` int(12) NOT NULL AUTO_INCREMENT,
  `game_answer` varchar(255) NOT NULL,
  `game_question_id_fk` int(12) NOT NULL,
  `correct_answer` int(11) NOT NULL DEFAULT '0',
  `game_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`game_answer_id`),
  KEY `game_question_id_fk` (`game_question_id_fk`),
  KEY `game_id_fk` (`game_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_question_answer`
--

INSERT INTO `game_question_answer` (`game_answer_id`, `game_answer`, `game_question_id_fk`, `correct_answer`, `game_id_fk`) VALUES
(5, '24630', 4, 0, 6),
(6, '25000', 4, 0, 6),
(7, '24600', 4, 0, 6),
(8, '24633', 4, 0, 6),
(9, '0.00746', 5, 0, 6),
(10, '0.00740', 5, 0, 6),
(11, '0.00750', 5, 0, 6),
(12, '0.00745', 5, 0, 6),
(13, '6.3 x 10', 2, 0, 6),
(14, '6.34 x 10', 2, 0, 6),
(15, '0.63 x 100', 2, 0, 6),
(16, '0.634 x 10', 2, 0, 6),
(17, '2.3 x 10^4', 9, 0, 6),
(18, '23 x 10^4', 9, 0, 6),
(19, '2.3 x 10^3', 9, 0, 6),
(20, '23 x 10^4', 9, 0, 6),
(21, 'ok', 27, 0, 30),
(22, 'pewdiepie', 27, 0, 30),
(23, 't series', 27, 0, 30),
(24, 'bitch lasagna', 27, 1, 30),
(25, '203 base 5', 10, 1, 2),
(26, '202 base 5', 10, 0, 2),
(27, '204 base 5', 10, 0, 2),
(28, '200 base 5', 10, 0, 2),
(29, '10110 base 2', 11, 0, 2),
(30, '10101 base 2', 11, 0, 2),
(31, '10100 base 2', 11, 0, 2),
(32, '10111 base 2', 11, 1, 2),
(33, '160 base 8', 12, 1, 2),
(34, '161 base 8', 12, 0, 2),
(35, '166 base 8', 12, 0, 2),
(36, '169 base 8', 12, 0, 2),
(37, '22 base 10', 13, 0, 2),
(38, '21 base 10', 13, 1, 2),
(39, '20 base 10', 13, 0, 2),
(40, '25 base 10', 13, 0, 2),
(41, '3C base 5', 14, 0, 2),
(42, '2E base 5', 14, 0, 2),
(43, '3D base 5', 14, 1, 2),
(44, '3E base 5', 14, 0, 2),
(45, '210', 15, 0, 2),
(46, '201', 15, 0, 2),
(47, '203', 15, 0, 2),
(48, '206', 15, 1, 2),
(49, '20', 16, 0, 2),
(50, '25', 16, 0, 2),
(51, '27', 16, 1, 2),
(52, '23', 16, 0, 2),
(53, '1010000 base 2', 17, 0, 2),
(54, '1010001 base 2', 17, 1, 2),
(55, '1010101 base 2', 17, 0, 2),
(56, '1010011 base 2', 17, 0, 2),
(57, '255', 18, 0, 2),
(58, '252', 18, 0, 2),
(59, '250', 18, 1, 2),
(60, '251', 18, 0, 2),
(61, '11101 base 2', 19, 1, 2),
(62, '11100 base 2', 19, 0, 2),
(63, '11111 base 2', 19, 0, 2),
(64, '11011 base 2', 19, 0, 2),
(65, '1313', 28, 0, 32),
(66, '12', 28, 0, 32),
(67, 'wooooo', 28, 1, 32),
(68, '123456789', 28, 0, 32),
(69, 'khoo', 29, 0, 33),
(70, 'eren', 29, 0, 33),
(71, 'wooi lok', 29, 1, 33),
(72, 'yew', 29, 0, 33);

-- --------------------------------------------------------

--
-- Table structure for table `game_result`
--

DROP TABLE IF EXISTS `game_result`;
CREATE TABLE IF NOT EXISTS `game_result` (
  `game_result_id` int(12) NOT NULL AUTO_INCREMENT,
  `game_result_time` time(6) NOT NULL,
  `game_result_score` int(5) NOT NULL DEFAULT '0',
  `game_result_point` int(5) NOT NULL DEFAULT '0',
  `user_game_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`game_result_id`),
  KEY `user_game_id_fk` (`user_game_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_result`
--

INSERT INTO `game_result` (`game_result_id`, `game_result_time`, `game_result_score`, `game_result_point`, `user_game_id_fk`) VALUES
(17, '02:53:46.000000', 60, 0, 43),
(18, '05:56:17.000000', 60, 0, 44),
(19, '06:06:45.000000', 60, 0, 45),
(20, '07:14:33.000000', 60, 0, 46),
(21, '07:42:10.000000', 60, 0, 47),
(22, '09:03:38.000000', 60, 45, 48),
(23, '11:18:08.000000', 60, 90, 49),
(24, '01:23:26.000000', 0, 0, 50),
(25, '01:23:35.000000', 0, 0, 51);

-- --------------------------------------------------------

--
-- Table structure for table `profileimg`
--

DROP TABLE IF EXISTS `profileimg`;
CREATE TABLE IF NOT EXISTS `profileimg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `user_id_fk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_fk` (`user_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profileimg`
--

INSERT INTO `profileimg` (`id`, `status`, `user_id_fk`) VALUES
(1, 0, 2),
(2, 0, 7),
(3, 0, 9);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
CREATE TABLE IF NOT EXISTS `quiz` (
  `quiz_id` int(12) NOT NULL AUTO_INCREMENT,
  `quiz_name` varchar(64) NOT NULL,
  `admin_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`quiz_id`),
  KEY `admin_id_fk` (`admin_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`quiz_id`, `quiz_name`, `admin_id_fk`) VALUES
(2, 'test out', 1),
(4, 'hello', 1),
(14, 'asdfghjkl', 1),
(15, 'example', 1),
(17, 'hello', 1),
(18, 'gtc', 1),
(19, 'hello there', 1),
(21, 'test', 1),
(22, 't gay', 1),
(23, 't gay', 1);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_answer`
--

DROP TABLE IF EXISTS `quiz_answer`;
CREATE TABLE IF NOT EXISTS `quiz_answer` (
  `quiz_answer_id` int(12) NOT NULL AUTO_INCREMENT,
  `quiz_answer` varchar(255) NOT NULL,
  `quiz_question_id_fk` int(12) NOT NULL,
  `correct_answer` int(255) NOT NULL DEFAULT '0',
  `quiz_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`quiz_answer_id`),
  KEY `quiz_question_id_fk` (`quiz_question_id_fk`),
  KEY `quiz_id_fk` (`quiz_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_answer`
--

INSERT INTO `quiz_answer` (`quiz_answer_id`, `quiz_answer`, `quiz_question_id_fk`, `correct_answer`, `quiz_id_fk`) VALUES
(1, 'T GAY', 2, 0, 2),
(2, 'BITCH LASAGNA', 2, 1, 2),
(5, 'TEST', 2, 0, 2),
(6, 'asdfghj', 2, 0, 2),
(25, '131', 13, 0, 19),
(26, 'qweqwe', 13, 1, 19),
(27, 'qweq', 13, 0, 19),
(28, 'qe', 13, 0, 19),
(33, 'T GAY', 2, 0, 2),
(34, 'BITCH LASAGNA', 2, 1, 2),
(35, 'TEST', 10, 0, 4),
(36, 'asdfghj', 10, 0, 4),
(37, '123', 10, 0, 4),
(38, '456', 10, 1, 4),
(39, '678', 14, 0, 4),
(40, 'idk', 14, 0, 4),
(41, '131', 14, 0, 4),
(42, 'qweqwe', 14, 1, 4),
(43, 'qweq', 14, 0, 4),
(44, 'qe', 14, 0, 4),
(45, 'okoko', 15, 0, 21),
(46, 'frgtyhju', 15, 0, 21),
(47, 'fghjk', 15, 0, 21),
(48, 'ghjkl', 15, 1, 21),
(49, 'dfghjkl', 16, 1, 22),
(50, 'fghjkl', 16, 0, 22),
(51, 'fghjkl', 16, 0, 22),
(52, 'fghjk', 16, 0, 22);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_comments`
--

DROP TABLE IF EXISTS `quiz_comments`;
CREATE TABLE IF NOT EXISTS `quiz_comments` (
  `quiz_comment_id` int(12) NOT NULL AUTO_INCREMENT,
  `quiz_comment` varchar(255) NOT NULL,
  `quiz_comment_date` date NOT NULL,
  `quiz_comment_vote` int(11) NOT NULL DEFAULT '0',
  `user_id_fk` int(12) NOT NULL,
  `quiz_question_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`quiz_comment_id`),
  KEY `user_quiz_id_fk` (`user_id_fk`),
  KEY `quiz_question_id_fk` (`quiz_question_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_comments`
--

INSERT INTO `quiz_comments` (`quiz_comment_id`, `quiz_comment`, `quiz_comment_date`, `quiz_comment_vote`, `user_id_fk`, `quiz_question_id_fk`) VALUES
(1, 'Testing', '2019-01-01', 3, 1, 2),
(3, 'asdfghjkl;', '2019-01-01', 3, 1, 10),
(4, 'Test', '2019-01-01', 3, 1, 2),
(5, 'Hello', '2019-01-01', 3, 1, 2),
(6, 'why', '2019-01-02', 0, 1, 2),
(7, 'wow', '2019-02-04', 0, 7, 2),
(8, 'ghjkl', '2019-02-04', 0, 7, 2),
(9, 'lol', '2019-02-04', 0, 7, 2),
(16, 'sadad', '2019-02-18', 0, 7, 14),
(17, 'sadad', '2019-02-18', 0, 7, 14),
(18, 'sadad', '2019-02-18', 0, 7, 14),
(21, 'wdfgh', '2019-02-18', 0, 7, 10);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_question`
--

DROP TABLE IF EXISTS `quiz_question`;
CREATE TABLE IF NOT EXISTS `quiz_question` (
  `quiz_question_id` int(12) NOT NULL AUTO_INCREMENT,
  `quiz_question` longtext NOT NULL,
  `quiz_image` blob,
  `quiz_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`quiz_question_id`),
  KEY `quiz_id_fk` (`quiz_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_question`
--

INSERT INTO `quiz_question` (`quiz_question_id`, `quiz_question`, `quiz_image`, `quiz_id_fk`) VALUES
(2, 'PEW PEW PEW', NULL, 2),
(10, 'qwertyui', NULL, 4),
(11, 'hello', NULL, 18),
(12, '', NULL, 18),
(13, 'qewqe`', NULL, 19),
(14, 'adsmaslm', NULL, 4),
(15, 'ddfghj', NULL, 21),
(16, 't gay banana', NULL, 22);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_result`
--

DROP TABLE IF EXISTS `quiz_result`;
CREATE TABLE IF NOT EXISTS `quiz_result` (
  `quiz_result_id` int(12) NOT NULL AUTO_INCREMENT,
  `quiz_result_time` time(6) DEFAULT NULL,
  `quiz_result_score` int(5) NOT NULL DEFAULT '0',
  `user_quiz_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`quiz_result_id`),
  KEY `user_quiz_id_fk` (`user_quiz_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_result`
--

INSERT INTO `quiz_result` (`quiz_result_id`, `quiz_result_time`, `quiz_result_score`, `user_quiz_id_fk`) VALUES
(1, '01:19:10.000000', 0, 2),
(2, '01:19:49.000000', 0, 3),
(3, '01:20:07.000000', 0, 4),
(4, '01:20:41.000000', 0, 5),
(5, '01:20:46.000000', 0, 6),
(6, '01:20:53.000000', 0, 7),
(7, '01:22:23.000000', 0, 8),
(8, '01:23:00.000000', 0, 9),
(9, '01:23:04.000000', 0, 10),
(10, '01:26:08.000000', 0, 13),
(11, '01:26:13.000000', 0, 14),
(12, '01:26:19.000000', 0, 15),
(13, '01:29:32.000000', 0, 16);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(64) NOT NULL,
  `user_password` varchar(256) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_honour_points` int(4) NOT NULL DEFAULT '1000',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_email`, `user_password`, `user_name`, `user_honour_points`) VALUES
(1, 'terencewong0427@gmail.com', '$2y$10$grx6sWbOprSE6asZQW1RLOUFpiMaiq0q3/prEaVoajxOC9Bvg0PHe', 'qx', 1000),
(2, 'terencewong990427@gmail.com', '$2y$10$il6q4A5X8JSxE0KIvjCo2O/hZFayuxJkj593I3S6Dh2NJMCVAs/DK', 'qx', 1000),
(3, 'terencewong27@gmail.com', '$2y$10$2qQUBy7wniEH2LjhNmyWL.WCss.MXA064R204l8YYaLZwciMABTG2', 'qixuan', 1000),
(4, 'terencewong@gmail.com', '$2y$10$uCeQJiRUEMCZ5IwvQ2un7uaGDePIwx8Spo3Q7jVw5/wfgxXIy/ODG', 'qixuan2', 1000),
(5, 'terencewong11110427@gmail.com', '$2y$10$8znTcGm/zZvbtPIWFKNjJem.Yhw1qcdzShj.FdH0/SvkgbSeqB1hu', 'aa', 1000),
(6, 'terencewong111110427@gmail.com', '$2y$10$qRM8VeTq55mSsvpk7c/m9.HGz5AvSpVOPUWElZSWRmIkoW2CrDUja', 'aaa', 1000),
(7, 'testing@mail.com', '$2y$10$kGDzXI2g43uJdWJINL1LtOdoQ2tQnnXTuIy.euTH6rtuEBqhWTsia', 'testing', 1135),
(9, 'gaimgenesis@gmail.com', '$2y$10$6BR42lhf2GdQaM3Y1Qc/LeoW4Ix.X/htp4PK73HOt65QxgF1e7vl.', 'TP046218', 1000),
(10, 'hello@gmail.com', '$2y$10$/qDmeYH2N0n569Fp7Qz95OfgGIRrWfTYopmhk0LdojWa9ijp80tA2', 'asdfghjkl', 1000),
(11, 'test@yahoo.com', '$2y$10$WykNvwlR1GwBwTeROeYJKeQjKqUrW/ThVRGBHM9oLEDseh.tLgaOm', 'asdsad', 1000),
(12, '123@mail.com', '$2y$10$aszPCr4rTTtiZ5zbAIIymuy5tLP/EBLNVluB9xTwfnwI9ztVNLdfy', 'asdasd', 1000),
(13, 'kiwamidrive@gmail.com', '$2y$10$pQAi.PgOMYlqRXzImPQISevUG94ltLl18Tb0EtJMHi3BcbshuJp..', 'gaim', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `user_game`
--

DROP TABLE IF EXISTS `user_game`;
CREATE TABLE IF NOT EXISTS `user_game` (
  `user_game_id` int(12) NOT NULL AUTO_INCREMENT,
  `user_game_date` date NOT NULL,
  `game_id_fk` int(12) NOT NULL,
  `user_id_fk` int(11) NOT NULL,
  PRIMARY KEY (`user_game_id`),
  KEY `game_id_fk` (`game_id_fk`),
  KEY `user_id_fk` (`user_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_game`
--

INSERT INTO `user_game` (`user_game_id`, `user_game_date`, `game_id_fk`, `user_id_fk`) VALUES
(1, '2018-10-10', 2, 3),
(2, '2019-01-03', 4, 5),
(33, '2019-02-17', 2, 7),
(34, '2019-02-17', 2, 7),
(35, '2019-02-18', 2, 7),
(36, '2019-02-18', 1, 7),
(37, '2019-02-18', 33, 7),
(38, '2019-02-18', 2, 7),
(39, '2019-02-18', 2, 7),
(40, '2019-02-18', 2, 7),
(41, '2019-02-18', 2, 7),
(42, '2019-02-18', 2, 7),
(43, '2019-02-18', 2, 7),
(44, '2019-02-18', 2, 7),
(45, '2019-02-18', 2, 7),
(46, '2019-02-18', 2, 7),
(47, '2019-02-18', 5, 7),
(48, '2019-02-18', 2, 7),
(49, '2019-02-18', 2, 7),
(50, '2019-02-18', 5, 7),
(51, '2019-02-18', 6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `user_game_answer`
--

DROP TABLE IF EXISTS `user_game_answer`;
CREATE TABLE IF NOT EXISTS `user_game_answer` (
  `user_answer_id` int(12) NOT NULL AUTO_INCREMENT,
  `user_selected_answer` varchar(5) NOT NULL,
  `game_result_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`user_answer_id`),
  KEY `game_result_id_fk` (`game_result_id_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_quiz`
--

DROP TABLE IF EXISTS `user_quiz`;
CREATE TABLE IF NOT EXISTS `user_quiz` (
  `user_quiz_id` int(12) NOT NULL AUTO_INCREMENT,
  `user_quiz_date` date NOT NULL,
  `quiz_id_fk` int(12) NOT NULL,
  `user_id_fk` int(11) NOT NULL,
  PRIMARY KEY (`user_quiz_id`),
  KEY `quiz_id_fk` (`quiz_id_fk`),
  KEY `user_id_fk` (`user_id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_quiz`
--

INSERT INTO `user_quiz` (`user_quiz_id`, `user_quiz_date`, `quiz_id_fk`, `user_id_fk`) VALUES
(1, '2019-10-18', 2, 1),
(2, '2019-02-18', 16, 7),
(3, '2019-02-18', 16, 7),
(4, '2019-02-18', 16, 7),
(5, '2019-02-18', 16, 7),
(6, '2019-02-18', 16, 7),
(7, '2019-02-18', 16, 7),
(8, '2019-02-18', 16, 7),
(9, '2019-02-18', 16, 7),
(10, '2019-02-18', 16, 7),
(13, '2019-02-18', 2, 7),
(14, '2019-02-18', 14, 7),
(15, '2019-02-18', 15, 7),
(16, '2019-02-18', 2, 7);

-- --------------------------------------------------------

--
-- Table structure for table `user_quiz_answer`
--

DROP TABLE IF EXISTS `user_quiz_answer`;
CREATE TABLE IF NOT EXISTS `user_quiz_answer` (
  `user_answer_id` int(12) NOT NULL AUTO_INCREMENT,
  `user_selected_answer` varchar(5) NOT NULL,
  `quiz_result_id_fk` int(12) NOT NULL,
  PRIMARY KEY (`user_answer_id`),
  KEY `quiz_result_id_fk` (`quiz_result_id_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `game` (`game_id`);

--
-- Constraints for table `game_question`
--
ALTER TABLE `game_question`
  ADD CONSTRAINT `game_question_ibfk_1` FOREIGN KEY (`game_id_fk`) REFERENCES `game` (`game_id`);

--
-- Constraints for table `game_question_answer`
--
ALTER TABLE `game_question_answer`
  ADD CONSTRAINT `game_question_answer_ibfk_1` FOREIGN KEY (`game_question_id_fk`) REFERENCES `game_question` (`game_question_id`),
  ADD CONSTRAINT `game_question_answer_ibfk_2` FOREIGN KEY (`game_id_fk`) REFERENCES `game` (`game_id`);

--
-- Constraints for table `game_result`
--
ALTER TABLE `game_result`
  ADD CONSTRAINT `game_result_ibfk_1` FOREIGN KEY (`user_game_id_fk`) REFERENCES `user_game` (`user_game_id`);

--
-- Constraints for table `profileimg`
--
ALTER TABLE `profileimg`
  ADD CONSTRAINT `profileimg_ibfk_1` FOREIGN KEY (`user_id_fk`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`admin_id_fk`) REFERENCES `admin` (`admin_id`);

--
-- Constraints for table `quiz_answer`
--
ALTER TABLE `quiz_answer`
  ADD CONSTRAINT `quiz_answer_ibfk_1` FOREIGN KEY (`quiz_question_id_fk`) REFERENCES `quiz_question` (`quiz_question_id`),
  ADD CONSTRAINT `quiz_answer_ibfk_2` FOREIGN KEY (`quiz_id_fk`) REFERENCES `quiz` (`quiz_id`);

--
-- Constraints for table `quiz_comments`
--
ALTER TABLE `quiz_comments`
  ADD CONSTRAINT `quiz_comments_ibfk_1` FOREIGN KEY (`user_id_fk`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `quiz_comments_ibfk_2` FOREIGN KEY (`quiz_question_id_fk`) REFERENCES `quiz_question` (`quiz_question_id`);

--
-- Constraints for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD CONSTRAINT `quiz_question_ibfk_1` FOREIGN KEY (`quiz_id_fk`) REFERENCES `quiz` (`quiz_id`);

--
-- Constraints for table `quiz_result`
--
ALTER TABLE `quiz_result`
  ADD CONSTRAINT `quiz_result_ibfk_1` FOREIGN KEY (`user_quiz_id_fk`) REFERENCES `user_quiz` (`user_quiz_id`);

--
-- Constraints for table `user_game`
--
ALTER TABLE `user_game`
  ADD CONSTRAINT `user_game_ibfk_2` FOREIGN KEY (`user_id_fk`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `user_game_ibfk_3` FOREIGN KEY (`game_id_fk`) REFERENCES `game` (`game_id`);

--
-- Constraints for table `user_game_answer`
--
ALTER TABLE `user_game_answer`
  ADD CONSTRAINT `user_game_answer_ibfk_1` FOREIGN KEY (`game_result_id_fk`) REFERENCES `game_result` (`game_result_id`);

--
-- Constraints for table `user_quiz`
--
ALTER TABLE `user_quiz`
  ADD CONSTRAINT `user_quiz_ibfk_2` FOREIGN KEY (`user_id_fk`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `user_quiz_ibfk_3` FOREIGN KEY (`quiz_id_fk`) REFERENCES `quiz_question` (`quiz_question_id`);

--
-- Constraints for table `user_quiz_answer`
--
ALTER TABLE `user_quiz_answer`
  ADD CONSTRAINT `user_quiz_answer_ibfk_1` FOREIGN KEY (`quiz_result_id_fk`) REFERENCES `quiz_result` (`quiz_result_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
