<?php
include "backend/connect.php";
if (isset($_GET['page_no']) && $_GET['page_no']!="") {
    $page_no = $_GET['page_no'];
    } else {
        $page_no = 1;
        }
        $total_records_per_page = 5;
$offset = ($page_no-1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = "2";
$result_count = mysqli_query(
$conn,
"SELECT COUNT(*) As total_records FROM game"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1; // total pages minus 1

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/menu.css"/>
<link rel="stylesheet" type="text/css" href="css/search.css"/>

<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<title>Manage Game</title>

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}


</style>
</head>

<body>

<!--- header ----->
<?php 

include_once 'template/header.php';
?>
<!----/header ---->


<!--------------Login Form ----------------->
<div style='width: 95vw;margin: 0 auto' >

<table><tr><th></th></tr>
<tr><td><p style="color: black; font-size: 30px; padding-left: 12px;">Game List
<div class="searchicon">
  <form method="post" action="">
       <input type="text" name="search_key" required="required" class="searchinput" placeholder="Search"/>
      <button type="submit" class="searchbtn"><i class="fa fa-search"></i></button>
  </form>
</div>
</td>
  
    <button id="myBtn" class="modalbox">Create New Game</button>
  <div id="myModal" class="modal">

  <!-- Modal content -->
       <form action="backend/creategame.inc.php" method="POST">
<div class="modal-content">
    <div class="modal-header">
      <span class="closebtn">&times;</span>
      <h2>Game Topic</h2>
    </div>
    <div class="modal-body">
      <p style="padding-left: 12px; font-size: 20px; font-weight: bold; color: black;">Topic Name: <input type="text" name="topic" value="" size="70%"><br><br>
        <div class="wrapper">  
      <button class="creategame creategame1">Create Game</button>  
    </div>
    </div>
</form>
</p>
  </p>

  <!--result should display after the html form! so php code at here!-->
  <?php
    //step 1: connection    
    //step 2: check whether the search key already exist or not
    // if exist, the search key with the variable searchkey
    if(isset($_POST['search_key']))
    {
      //store the search key with the variable $searchkey
      $searchkey = $_POST['search_key'];
      
      //step 3: create search sql query
      $sql = "Select * from game where game_name LIKE '%$searchkey%';";
      $result = mysqli_query($conn, $sql);
      
      if(mysqli_num_rows($result)<=0)
      {
        echo "<script>alert('No topic found!');</script>";
      }
      
      echo "<table id='quiztopic'>";
      echo "<thead>";
      echo "<tr>";
      echo "<th style='width:1200px'></th>";
      echo "<th></th>";
      echo "<th></th>";
      echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
      while($row = mysqli_fetch_assoc($result))
    {
      echo "<tr>";
      echo "<td>".$row['game_name']."</td>";
      echo "<td><a href='editgames.php?id=".$row['game_id']."'>";
  echo "<button class='play play1'>Edit</button></a></td>";
  echo "<td><a href='backend/deletegame.inc.php?id=".$row['game_id']."'>";
  echo "<button class='play play1'>Delete</button></a></td>";
  echo"</tr>";
    }

    echo "</table>";
    }
  ?>
</tbody>
</table>
<center>
<table id="quiztopic">
<thead>
<tr>
<th style="width: 1200px">Topic Name</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
$result = mysqli_query(
    $conn,
    "SELECT * FROM game LIMIT $offset, $total_records_per_page"
    );
while($row = mysqli_fetch_array($result)){
    echo "<tr>";
  echo "<td>".$row['game_name']."</td>";
  echo "<td><a href='editgames.php?id=".$row['game_id']."'>";
  echo "<button class='play play1'>Edit</button></a></td>";
  echo "<td><a href='backend/deletegame.inc.php?id=".$row['game_id']."'>";
  echo "<button class='play play1'>Delete</button></a></td>";
  echo"</tr>";
        }
mysqli_close($conn);
?>
</tbody>
</table></center>
<br/><br/>
<div class="pagination">
<?php if($page_no <= 1){ echo ""; } ?>
<a <?php if($page_no > 1){
echo "href='?page_no=$previous_page'";
} ?>>Previous</a>
    
<?php if($page_no >= $total_no_of_pages){
echo "";
} ?>
<a <?php if($page_no < $total_no_of_pages) {
echo "href='?page_no=$next_page'";
} ?>>Next</a>
 

</div>
</div>
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("closebtn")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

<!--------------Footer ----------------->
<?php  
include_once 'template/footer.php';
?>

<!--------------/footer------------------>


</body>

</html>
