﻿<?php 
include "backend/connect.php";
if (isset($_GET['page_no']) && $_GET['page_no']!="") {
    $page_no = $_GET['page_no'];
    } else {
        $page_no = 1;
        }
        $total_records_per_page = 5;
$offset = ($page_no-1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = "2";
$result_count = mysqli_query(
$conn,
"SELECT COUNT(*) As total_records FROM game"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1; // total pages minus 1
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" type="text/css" href="css/logo.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/loader.css"/>
<link rel="stylesheet" type="text/css" href="css/search.css"/>
<link rel="stylesheet" type="text/css" href="css/menu.css"/>
<script type="text/javascript" src="js/header.js"></script>
<link rel="stylesheet" type="text/css" href="css/snow.css" id="snowflakecss"/>
<script type="text/javascript" src="js/snow.js"></script>


<meta name="viewport" content="width=device-width, initial-scale=1"/>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<title>Game</title>

<style>
/* clash with bootstrap component tag, use embed to override it */
body{
margin: 0;
background: #f7f7f7;
color: black;
font-family: 'Montserrat', sans-serif; 
overflow-x: hidden;
overflow-y: scroll;
}

h1,h2 {
  font-weight: bold;
}

p {
  font-size: 16px;
  color: #cdcdcd;
}

/*apply to all elements */
* {
  box-sizing: border-box;
}

/*style the nav bar */
.navbar-inverse {
  background: #2E2F31;
  border: 0;
}
.navbar-inverse .navbar-nav li a {
  color: #f7f7f7;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li a:hover {
  color: #CC0000;
  font-size: 20px;
}

.navbar-inverse .navbar-nav li button {
  color: #f7f7f7;
  background-color: Transparent;
  border: none;
  line-height: 3.0;
  font-size: 16px;
}
.navbar-inverse .navbar-nav li button:hover {
  color: #CC0000;
  background-color: Transparent;
  border: none;
  font-size: 20px;
}

#gametopic {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  font-size: 20px;
  border-collapse: collapse;
  width: 100%;
}

#gametopic td, #gametopic th {
  border: 1px solid #ddd;
  padding: 12px;
  padding-left: 30px;
}

#gametopic tr:nth-child(even){background-color: #f2f2f2;}

#gametopic tr:hover {background-color: #ddd;}

#gametopic th {
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left: 25px;
  text-align: left;
  background-color: grey;
  color: white;
}
.play {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
  display:block;
  margin-left: auto;
  margin-right: auto;
}

.play1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}

.play1:hover {
  background-color: #4CAF50;
  color: white;
}
.pagination {
  display: inline-block;

}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
</head>

<body>

<!--- header ----->
<?php 

include_once 'template/header.php';

?>
<!----/header ---->

<!--------------Search bar ----------------->
<div style='width: 95vw;margin: 0 auto' >
<p style="color: black; font-size: 30px; padding-left: 12px;">Games List </p>

<div class="searchicon">
  <form method="post" action="">
       <input type="text" name="search_key" required="required" class="searchinput" placeholder="Search"/>
      <button type="submit" class="searchbtn"><i class="fa fa-search"></i></button>
  </form>
</div>
<br/>


  <!--result should display after the html form! so php code at here!-->
  <?php
    //step 1: connection    
    //step 2: check whether the search key already exist or not
    // if exist, the search key with the variable searchkey
    if(isset($_POST['search_key']))
    {
      //store the search key with the variable $searchkey
      $searchkey = $_POST['search_key'];
      
      //step 3: create search sql query
      $sql = "Select * from game where game_name LIKE '%$searchkey%';";
      $result = mysqli_query($conn, $sql);
      
      if(mysqli_num_rows($result)<=0)
      {
        echo "<script>alert('No topic found!');</script>";
      }
      
      echo "<table id='gametopic'>";
      echo "<thead>";
      echo "<tr>";
      echo "<th style='width:75vw'>Topic Name</th>";
      echo "<th></th>";
      echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
    $gameids = array();
    $gamenames = array();
      while($row = mysqli_fetch_assoc($result))
          {
    array_push($gameids, $row['game_id']);
    array_push($gamenames, $row['game_name']);
          }

        $c = sizeof($gameids);
        //echo $c;
        for ($i=0; $i<$c;$i++)
        {
          echo "<tr>";
          echo "<td>$gamenames[$i]</td>";
          echo "<td>";
          echo "<button class='play play1' onclick='pop".$i."()'>Play</button></td>";         
          echo "</tr>";
          echo "<div class='popup' id='pop".$i."' onclick='closepop()'><div class='popup-contnet'><br/><center><h2>Are you sure you wants to enter the game?</h2></center><br/><form method='POST' action='selectOpponent.php'><input type='hidden' name='gid' value='".$gameids[$i]."'/><input type='hidden' name='uid' value='".$_SESSION['uid']."'/>";
  echo "<button type='submit' class='play play1'>Play</button></a></form></div></div>";

        }

    echo "</table>";
    }
  ?>
</tbody>
</table>
<center>
<table id="gametopic">
<thead>
<tr>
<th style="width: 75vw">Topic Name</th>
<th></th>
</tr>
</thead>
<tbody>

  <script>
  function pop1() {

    document.getElementById('pop1').style.display = 'block';
  }
  function pop2() {

  document.getElementById('pop2').style.display = 'block';
  }
  function pop3() {

  document.getElementById('pop3').style.display = 'block';
  }
  function pop4() {

   document.getElementById('pop4').style.display = 'block';
  }
  function pop0() {

  document.getElementById('pop0').style.display = 'block';
}

  function closepop() {
    document.getElementById('pop0').style.display = 'none';
    document.getElementById('pop1').style.display = 'none';
    document.getElementById('pop2').style.display = 'none';
    document.getElementById('pop3').style.display = 'none';
    document.getElementById('pop4').style.display = 'none';
  }
</script>
<?php
$result = mysqli_query(
    $conn,
    "SELECT * FROM game LIMIT $offset, $total_records_per_page"
    );
    $gameid = array();
    $gamename = array();
while($row = mysqli_fetch_array($result))
        {
    array_push($gameid, $row['game_id']);
    array_push($gamename, $row['game_name']);
        }

        $c = sizeof($gameid);
        //echo $c;
        for ($i=0; $i<$c;$i++)
        {
          echo "<tr>";
          echo "<td>$gamename[$i]</td>";
          echo "<td>";
          echo "<button class='play play1' onclick='pop".$i."()'>Play</button></td>";         
          echo "</tr>";
          echo "<div class='popup' id='pop".$i."' onclick='closepop()'><div class='popup-contnet'><br/><h2>Are you sure you wants to enter the game?</h2><br/><form method='POST' action='selectOpponent.php'><input type='hidden' name='gid' value='".$gameid[$i]."'/><input type='hidden' name='uid' value='".$_SESSION['uid']."'/>";
  echo "<button type='submit' class='play play1'>Play</button></a></form></div></div>";

        }
mysqli_close($conn);
?>
</tbody>
</table></center>
<br/><br/>
<div class="pagination">
<?php if($page_no <= 1){ echo ""; } ?>
<a <?php if($page_no > 1){
echo "href='?page_no=$previous_page'";
} ?> style="cursor: pointer">Previous</a>
    
<?php if($page_no >= $total_no_of_pages){
echo "";
} ?>
<a <?php if($page_no < $total_no_of_pages) {
echo "href='?page_no=$next_page'";
} ?> style="cursor: pointer">Next</a>
 

</div>
</div>

<!--------------Footer ----------------->
<?php  
include_once 'template/footer.php';
?>

<!--------------/footer------------------>


</body>

</html>
