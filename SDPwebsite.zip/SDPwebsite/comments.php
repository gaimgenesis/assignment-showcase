<?php
	include "backend/connect.php";
	$id = $_GET['id'];
	$sql = "Select * from quiz_comments LEFT JOIN quiz_question ON quiz_question_id = quiz_question_id_fk LEFT JOIN user ON user_id_fk = user_id where quiz_question_id = $id";
	$result = mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)<=0)
	{
		echo "No results.";
	}
	while($rows=mysqli_fetch_array($result))
	{
		echo "<h3>".$rows['quiz_comment']."</h3>";
		echo "<h3>".$rows['quiz_comment_date']."</h3>";
		echo "<h3>".$rows['user_name']."</h3>";
	}
?>